# essential/ — Extracted StudyVibe Modules

Copied verbatim from `studyvibe---cinematic-study.zip` preserving original paths:

## 1. Draggable Widgets Flow
- `src/components/widgets/FloatingPomodoro.tsx`
- `src/components/widgets/FloatingMusicPlayer.tsx`
- `src/router.tsx` (reference for global widget mounting)

## 2. Music Player & Music System
- `src/context/MusicContext.tsx`
- `src/pages/Music.tsx`
- `src/components/notes/AudioPlayer.tsx`
- `src/App.tsx` (reference for `<MusicProvider>` inside `<SettingsProvider>`)
- `server.ts` (lines 916–989: `GET /api/yt-stream`)

## 3. Batches Videos & Extraction Strategy
- `src/pages/Batch.tsx`
- `server.ts` (lines 1–915: `GET /api/playlist` 4-tier extraction waterfall — Native HTML/InnerTube Continuation -> Invidious -> YouTube Data API v3 -> Gemini AI fallback)

## 4. Shared Local Dependencies (Imported by the Files Above)
- `src/lib/utils.ts`
- `src/lib/fileStorage.ts`
- `src/lib/firebase.ts`
- `src/context/SettingsContext.tsx`
- `src/context/AuthContext.tsx`
- `src/components/GlassCard.tsx`
- `src/components/GlowButton.tsx`
- `src/components/ui/KineticText.tsx`
- `package.json`
