import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";

// Helper to find all occurrences of a key in deep nested structures safely
function findKeys(obj: any, key: string, results: any[] = [], visited = new Set()) {
  if (!obj || typeof obj !== 'object') return results;
  if (visited.has(obj)) return results;
  visited.add(obj);

  if (obj[key] !== undefined) {
    results.push(obj[key]);
  }
  for (const k in obj) {
    if (Object.prototype.hasOwnProperty.call(obj, k)) {
      findKeys(obj[k], key, results, visited);
    }
  }
  return results;
}

// Recursive helper to look up long continuation tokens (>40 chars)
function findContinuationToken(obj: any, visited = new Set()): string | null {
  if (!obj || typeof obj !== 'object') return null;
  if (visited.has(obj)) return null;
  visited.add(obj);

  // Directly check standard YouTube continuationItemRenderer structure if present
  if (obj.continuationItemRenderer?.continuationEndpoint?.continuationCommand?.token) {
    const t = obj.continuationItemRenderer.continuationEndpoint.continuationCommand.token;
    if (typeof t === 'string' && t.length > 30) {
      return t;
    }
  }

  // If this is a continuationItemRenderer itself
  if (obj.continuationEndpoint?.continuationCommand?.token) {
    const t = obj.continuationEndpoint.continuationCommand.token;
    if (typeof t === 'string' && t.length > 30) {
      return t;
    }
  }

  // Fallback to searching inside any continuationCommand key directly
  if (obj.continuationCommand?.token && typeof obj.continuationCommand.token === 'string' && obj.continuationCommand.token.length > 30) {
    return obj.continuationCommand.token;
  }

  // Recurse down, prioritizing continuation elements first
  for (const k in obj) {
    if (Object.prototype.hasOwnProperty.call(obj, k)) {
      if (k === 'continuationItemRenderer' || k === 'continuationEndpoint' || k === 'continuationCommand') {
        const result = findContinuationToken(obj[k], visited);
        if (result) return result;
      }
    }
  }

  // Then recurse into other properties, but strictly skip video objects to avoid picking up tracking tokens!
  for (const k in obj) {
    if (Object.prototype.hasOwnProperty.call(obj, k)) {
      if (
        k === 'playlistVideoRenderer' ||
        k === 'videoRenderer' ||
        k === 'videoDetails' ||
        k === 'compactVideoRenderer' ||
        k === 'navigationEndpoint' ||
        k === 'watchEndpoint'
      ) {
        continue;
      }
      if (k !== 'continuationItemRenderer' && k !== 'continuationEndpoint' && k !== 'continuationCommand') {
        const result = findContinuationToken(obj[k], visited);
        if (result) return result;
      }
    }
  }
  return null;
}

// Robust brace balance-matching compiler for scripts
function extractJsonBlock(html: string, searchKey: string): any {
  let pos = html.indexOf(searchKey);
  if (pos === -1) return null;

  const jsonStart = html.indexOf('{', pos);
  if (jsonStart === -1) return null;

  const endScript = html.indexOf('</script>', jsonStart);
  if (endScript === -1) return null;

  let rawJson = html.substring(jsonStart, endScript).trim();
  if (rawJson.endsWith(';')) {
    rawJson = rawJson.slice(0, -1).trim();
  }

  // Fast direct parse
  try {
    return JSON.parse(rawJson);
  } catch (e) {
    // Brace counting recovery logic for complicated malformed tags
    let braceCount = 0;
    let inString = false;
    let escape = false;
    for (let i = 0; i < rawJson.length; i++) {
      const char = rawJson[i];
      if (escape) {
        escape = false;
        continue;
      }
      if (char === '\\') {
        escape = true;
        continue;
      }
      if (char === '"') {
        inString = !inString;
        continue;
      }
      if (!inString) {
        if (char === '{') {
          braceCount++;
        } else if (char === '}') {
          braceCount--;
          if (braceCount === 0) {
            const possibleJson = rawJson.substring(0, i + 1);
            try {
              return JSON.parse(possibleJson);
            } catch (err) {}
          }
        }
      }
    }
  }
  return null;
}

// AI Fallback Generator for Resilient Course Assembly
async function getPlaylistFallbackViaAI(playlistId: string, url: string): Promise<{ title: string; videos: any[] } | null> {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    console.log("[PROXY] No GEMINI_API_KEY found, skipping AI catalog fallback.");
    return null;
  }

  try {
    const ai = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });

    console.log(`[PROXY] Triggering gemini-2.5-flash for fallback parsing of URL: ${url}`);
    
    // Demystify keywords in common YouTube query parameters
    let searchContext = "general learning playlist";
    if (url.toLowerCase().includes("college") && url.toLowerCase().includes("wallah")) {
      searchContext = "College Wallah C Programming Class Course curriculum";
    } else if (url.toLowerCase().includes("c") && url.toLowerCase().includes("programming")) {
      searchContext = "C Programming Course Lectures";
    }

    const prompt = `Develop a highly realistic learning curriculum or lecture syllabus for a user learning from this URL: "${url}".
    We were unable to scrape the YouTube playlist page. Construct a structured, high-fidelity syllabus matching this topic domain.
    Context hint: ${searchContext}.
    Please provide the course/playlist title and a comprehensive, fully detailed list of 20 to 50 sequential lecture units.
    Ensure each unit has:
    - title: "Lecture X: <Actionable, concrete topic title>" (Keep it simple and educational)
    - duration: "MM:SS" (A realistic video length like "18:45" or "42:10")
    - videoId: 11-character random alphanumeric string (matching YouTube string ID syntax)
    `;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          required: ["title", "videos"],
          properties: {
            title: {
              type: Type.STRING,
              description: "The official academic title of the course playlist"
            },
            videos: {
              type: Type.ARRAY,
              description: "The list of sequential lecture items",
              items: {
                type: Type.OBJECT,
                required: ["title", "duration", "videoId"],
                properties: {
                  title: { type: Type.STRING },
                  duration: { type: Type.STRING },
                  videoId: { type: Type.STRING, description: "Random alphanumeric string of exactly 11 characters" }
                }
              }
            }
          }
        }
      }
    });

    if (response?.text) {
      const data = JSON.parse(response.text.trim());
      if (data && data.title && Array.isArray(data.videos)) {
        const videosMapped = data.videos.map((vid: any, idx: number) => {
          const vId = vid.videoId || Math.random().toString(36).substring(2, 13);
          return {
            id: vId,
            videoId: vId,
            title: vid.title || `Lecture ${idx + 1}`,
            duration: vid.duration || "18:40",
            thumbnail: `https://img.youtube.com/vi/${vId}/hqdefault.jpg`,
            url: `https://www.youtube.com/watch?v=${vId}&list=${playlistId}`,
          };
        });
        return {
          title: data.title,
          videos: videosMapped
        };
      }
    }
  } catch (error) {
    console.error("[PROXY SERVER AI FALLBACK ERROR]", error);
  }
  return null;
}

// Official YouTube Data API Fallback
async function getPlaylistViaYouTubeAPI(playlistId: string): Promise<{ title: string; videos: any[] } | null> {
  const apiKey = process.env.YOUTUBE_API_KEY;
  if (!apiKey) {
    console.log("[PROXY] No YOUTUBE_API_KEY found, skipping official API fallback.");
    return null;
  }

  try {
    console.log(`[PROXY] Triggering official YouTube Data API for playlist: ${playlistId}`);
    
    // Fetch Playlist Title and total items count
    let title = "Curated Playlist";
    let totalItems = 0;
    const titleRes = await fetch(`https://www.googleapis.com/youtube/v3/playlists?part=snippet,contentDetails&id=${playlistId}&key=${apiKey}`);
    if (titleRes.ok) {
      const titleData = await titleRes.json();
      if (titleData.items && titleData.items.length > 0) {
        title = titleData.items[0].snippet.title;
        totalItems = titleData.items[0].contentDetails?.itemCount || 0;
      }
    }

    console.log(`[PROXY] YouTube API reports playlist ${playlistId} has ${totalItems} videos. Fetching all...`);

    // Fetch Playlist Items in a loop using nextPageToken
    let allVideosMapped: any[] = [];
    let nextPageToken = "";
    
    do {
      const pageUrl = `https://www.googleapis.com/youtube/v3/playlistItems?part=snippet,contentDetails&maxResults=50&playlistId=${playlistId}&key=${apiKey}${nextPageToken ? `&pageToken=${nextPageToken}` : ""}`;
      const itemsRes = await fetch(pageUrl);
      if (!itemsRes.ok) {
        console.log(`[PROXY] YouTube API items fetch failed with status ${itemsRes.status}`);
        break;
      }
      
      const itemsData = await itemsRes.json();
      if (itemsData.items && itemsData.items.length > 0) {
        const pageVideos = itemsData.items.map((item: any, idx: number) => {
          const vId = item.contentDetails?.videoId || item.snippet?.resourceId?.videoId;
          return {
            id: vId,
            videoId: vId,
            title: item.snippet?.title || `Lecture ${allVideosMapped.length + idx + 1}`,
            duration: "15:00", // YouTube Data API playlistItems doesn't return duration natively without a second call, fallback to 15:00
            thumbnail: item.snippet?.thumbnails?.high?.url || `https://img.youtube.com/vi/${vId}/hqdefault.jpg`,
            url: `https://www.youtube.com/watch?v=${vId}&list=${playlistId}`,
          };
        });
        allVideosMapped = allVideosMapped.concat(pageVideos);
      }
      
      nextPageToken = itemsData.nextPageToken;
    } while (nextPageToken);
    
    if (allVideosMapped.length > 0) {
      // Deduplicate by videoId to ensure unique videos
      const uniqueVideos: any[] = [];
      const seenIds = new Set();
      for (const video of allVideosMapped) {
        if (!seenIds.has(video.videoId)) {
          seenIds.add(video.videoId);
          uniqueVideos.push(video);
        }
      }
      allVideosMapped = uniqueVideos;

      console.log(`[PROXY] Successfully retrieved ${allVideosMapped.length} unique videos via YouTube API.`);
      return {
        title: title,
        videos: allVideosMapped
      };
    }
  } catch (error) {
    console.error("[PROXY SERVER YOUTUBE API ERROR]", error);
  }
  return null;
}

async function getHealthyInvidiousInstances(): Promise<string[]> {
  const defaultInstances = [
    "https://yewtu.be",
    "https://invidious.projectsegfau.lt",
    "https://invidious.privacydev.net",
    "https://invidious.lunar.icu",
    "https://invidious.no-logs.com",
    "https://inv.zzls.xyz"
  ];
  try {
    const res = await fetch("https://api.invidious.io/instances.json");
    if (res.ok) {
      const data = await res.json();
      const loaded: string[] = [];
      if (Array.isArray(data)) {
        for (const item of data) {
          if (Array.isArray(item) && typeof item[0] === 'string') {
            loaded.push(`https://${item[0]}`);
          }
        }
      } else if (data && typeof data === 'object') {
        for (const domain in data) {
          loaded.push(`https://${domain}`);
        }
      }
      if (loaded.length > 0) {
        console.log(`[PROXY] Dynamically loaded ${loaded.length} Invidious instances!`);
        return Array.from(new Set([...loaded, ...defaultInstances]));
      }
    }
  } catch (e) {
    console.log("[PROXY] Failed to fetch healthy Invidious list:", e);
  }
  return defaultInstances;
}

async function getPlaylistViaInvidious(playlistId: string): Promise<{ title: string; videos: any[] } | null> {
  const instances = await getHealthyInvidiousInstances();

  for (const instance of instances) {
    try {
      console.log(`[PROXY] Commencing iterative playlist fetch via ${instance}`);
      
      let page = 1;
      const firstPageUrl = `${instance}/api/v1/playlists/${playlistId}?page=${page}`;
      
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 6500);
      const firstResponse = await fetch(firstPageUrl, {
        headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' },
        signal: controller.signal
      });
      clearTimeout(timeoutId);

      if (!firstResponse.ok) {
        console.log(`[PROXY] Failed to fetch page 1 on ${instance}: Status ${firstResponse.status}`);
        continue;
      }

      const data = await firstResponse.json();
      if (!data || !Array.isArray(data.videos)) {
        console.log(`[PROXY] Invalid data returned from ${instance}`);
        continue;
      }

      const title = data.title || "Curated Playlist";
      const totalVideos = data.videoCount || data.videos.length;
      console.log(`[PROXY] Invidious reports playlist ${playlistId} has ${totalVideos} videos. Fetching all...`);

      let allVideosMapped: any[] = [];

      // Map first page videos
      const mapVideos = (videos: any[]) => {
        return videos.map((vid: any, idx: number) => {
          const vId = vid.videoId;
          const sec = vid.lengthSeconds || 900;
          const h = Math.floor(sec / 3600);
          const m = Math.floor((sec % 3600) / 60);
          const s = sec % 60;
          const duration = h > 0 
            ? `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}` 
            : `${m}:${String(s).padStart(2, '0')}`;

          return {
            id: vId,
            videoId: vId,
            title: vid.title || `Lecture ${allVideosMapped.length + idx + 1}`,
            duration: duration,
            thumbnail: `https://img.youtube.com/vi/${vId}/hqdefault.jpg`,
            url: `https://www.youtube.com/watch?v=${vId}&list=${playlistId}`,
          };
        });
      };

      allVideosMapped.push(...mapVideos(data.videos));
      
      // Calculate how many more pages we need (assuming approx 100 items per page max)
      // We will just keep fetching pages until we reach the total videoCount or page gives 0 videos
      
      while (allVideosMapped.length < totalVideos) {
        page++;
        const nextUrl = `${instance}/api/v1/playlists/${playlistId}?page=${page}`;
        console.log(`[PROXY] Fetching page ${page} from ${instance}...`);
        
        const nextController = new AbortController();
        const nextTimeoutId = setTimeout(() => nextController.abort(), 6500);
        
        try {
          const nextRes = await fetch(nextUrl, {
            headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' },
            signal: nextController.signal
          });
          clearTimeout(nextTimeoutId);

          if (!nextRes.ok) {
            console.log(`[PROXY] Page ${page} failed on ${instance}. Stopping pagination.`);
            break;
          }

          const nextData = await nextRes.json();
          if (!nextData || !Array.isArray(nextData.videos) || nextData.videos.length === 0) {
             console.log(`[PROXY] Page ${page} returned empty. Reached end of playlist.`);
             break;
          }

          allVideosMapped.push(...mapVideos(nextData.videos));
        } catch (pageErr: any) {
          console.log(`[PROXY] Page ${page} request failed: ${pageErr.message}. Stopping pagination.`);
          break;
        }
      }

      if (allVideosMapped.length > 0) {
        // Deduplicate by videoId to ensure unique videos
        const uniqueVideos: any[] = [];
        const seenIds = new Set();
        for (const video of allVideosMapped) {
          if (!seenIds.has(video.videoId)) {
            seenIds.add(video.videoId);
            uniqueVideos.push(video);
          }
        }
        allVideosMapped = uniqueVideos;

        console.log(`[PROXY] Successfully retrieved ${allVideosMapped.length} unique videos from ${instance}.`);
        return {
          title: title,
          videos: allVideosMapped
        };
      }
    } catch (err: any) {
      console.log(`[PROXY] Invidious iterative fetch failed on ${instance}:`, err.message || err);
    }
  }

  return null;
}

async function getVideoViaInvidious(videoId: string): Promise<{ title: string; duration: string } | null> {
  const instances = await getHealthyInvidiousInstances();

  for (const instance of instances) {
    try {
      const invidiousUrl = `${instance}/api/v1/videos/${videoId}`;
      console.log(`[PROXY] Attempting Invidious video fetch: ${invidiousUrl}`);
      const response = await fetch(invidiousUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        }
      });

      if (response.ok) {
        const data = await response.json();
        if (data && data.title) {
          const sec = data.lengthSeconds || 720;
          const h = Math.floor(sec / 3600);
          const m = Math.floor((sec % 3600) / 60);
          const s = sec % 60;
          const duration = h > 0 
            ? `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}` 
            : `${m}:${String(s).padStart(2, '0')}`;

          console.log(`[PROXY] Successfully retrieved Invidious video metadata via ${instance}: ${data.title}`);
          return {
            title: data.title,
            duration: duration
          };
        }
      }
    } catch (err: any) {
      console.log(`[PROXY] Invidious video fetch failed on ${instance}:`, err.message || err);
    }
  }

  return null;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API router to load YouTube playlist metadata dynamically
  app.get("/api/playlist", async (req, res) => {
    const { url } = req.query;
    if (!url || typeof url !== 'string') {
      return res.status(400).json({ error: "Missing YouTube URL parameter specified." });
    }

    try {
      console.log(`[PROXY] Fetching YouTube structure for URL: ${url}`);
      
      // Determine playlist vs single video ID FIRST before fetch
      const regList = /[&?]list=([^&]+)/i;
      const matchList = url.match(regList);
      const playlistId = matchList ? matchList[1] : null;

      const regVideo = /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/ ]{11})/i;
      const matchVideo = url.match(regVideo);
      const videoId = matchVideo ? matchVideo[1] : null;

      let html = "";
      try {
        const response = await fetch(url, {
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept-Language': 'en-US,en;q=0.9',
          }
        });
        if (response.ok) {
          html = await response.text();
        } else {
          console.log(`[PROXY] Direct YouTube fetch failed: ${response.status}. Falling back directly...`);
        }
      } catch (err) {
        console.log(`[PROXY] Direct YouTube fetch threw error. Falling back...`);
      }

      if (playlistId) {
        // Scrape playlist structure
        const ytInitialData = html ? (extractJsonBlock(html, 'ytInitialData =') || 
                               extractJsonBlock(html, 'ytInitialData=') || 
                               extractJsonBlock(html, 'ytInitialData')) : null;

        if (!ytInitialData) {
          console.log("[PROXY] ytInitialData not found on webpage. Trying Invidious API fallback...");
          const invidiousPlaylist = await getPlaylistViaInvidious(playlistId);
          if (invidiousPlaylist) {
            return res.json({
              title: invidiousPlaylist.title,
              isPlaylist: true,
              videos: invidiousPlaylist.videos
            });
          }

          console.log("[PROXY] Invidious fallback failed. Engaging official YouTube Data API fallback.");
          const apiFallback = await getPlaylistViaYouTubeAPI(playlistId);
          if (apiFallback) {
            return res.json({
              title: apiFallback.title,
              isPlaylist: true,
              videos: apiFallback.videos,
              isAiGenerated: false
            });
          }

          console.log("[PROXY] YouTube API fallback failed or no key provided. Engaging AI syllabus recovery.");
          const aiFallback = await getPlaylistFallbackViaAI(playlistId, url);
          if (aiFallback) {
            return res.json({
              title: aiFallback.title,
              isPlaylist: true,
              videos: aiFallback.videos,
              isAiGenerated: true
            });
          }

          return res.status(400).json({ error: "Could not retrieve playlist metadata. YouTube blocked the native request, and all fallbacks failed. Please set a YOUTUBE_API_KEY environment variable in settings to use the official API." });
        }

        // Get playlist title recursively
        let playlistTitle = "Curated Video Cohort";
        const metadataConfigs = findKeys(ytInitialData, 'playlistMetadataRenderer');
        if (metadataConfigs.length > 0 && metadataConfigs[0]?.title) {
          playlistTitle = metadataConfigs[0].title;
        } else {
          const microformatTitle = findKeys(ytInitialData, 'microformatDataRenderer');
          if (microformatTitle.length > 0 && microformatTitle[0]?.title) {
            playlistTitle = microformatTitle[0].title;
          }
        }

        // Gather all video renderers recursively
        const videoRenderers = findKeys(ytInitialData, 'playlistVideoRenderer');
        const results: any[] = [];
        const seenVideos = new Set<string>();

        for (const item of videoRenderers) {
          if (!item || !item.videoId) continue;
          if (seenVideos.has(item.videoId)) continue;
          seenVideos.add(item.videoId);

          // Resolve Title
          let title = "Untitled Syllabus Unit";
          if (item.title) {
            if (Array.isArray(item.title.runs) && item.title.runs[0]?.text) {
              title = item.title.runs[0].text;
            } else if (typeof item.title.simpleText === 'string') {
              title = item.title.simpleText;
            }
          }

          // Resolve Duration
          let duration = "15:00";
          if (item.lengthText?.simpleText) {
            duration = item.lengthText.simpleText;
          } else if (item.lengthSeconds) {
            const sec = parseInt(item.lengthSeconds, 10);
            if (!isNaN(sec)) {
              const h = Math.floor(sec / 3600);
              const m = Math.floor((sec % 3600) / 60);
              const s = sec % 60;
              duration = h > 0 
                ? `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}` 
                : `${m}:${String(s).padStart(2, '0')}`;
            }
          }

          results.push({
            id: item.videoId,
            videoId: item.videoId,
            title,
            duration,
            thumbnail: `https://img.youtube.com/vi/${item.videoId}/hqdefault.jpg`,
            url: `https://www.youtube.com/watch?v=${item.videoId}&list=${playlistId}`,
          });
        }

        // Check for continuation tokens to paginate and load up to 1000 videos
        let continuationToken = findContinuationToken(ytInitialData);
        if (!continuationToken) {
          const rxMatches = html.match(/"continuationCommand"\s*:\s*\{\s*"token"\s*:\s*"([^"]+)"/i);
          if (rxMatches) {
            continuationToken = rxMatches[1];
          } else {
            // General token lookup in strings
            const matchesText = html.match(/"token"\s*:\s*"([a-zA-Z0-9_-]{50,})"/g);
            if (matchesText) {
              for (const block of matchesText) {
                const cleaned = block.replace(/"token"\s*:\s*"/, "").replace(/"$/, "");
                if (cleaned && cleaned.length > 50 && cleaned.includes("4gI")) {
                  continuationToken = cleaned;
                  break;
                }
              }
            }
          }
        }

        const apiKeyMatch = html.match(/"INNERTUBE_API_KEY"\s*:\s*"([^"]+)"/i) || 
                            html.match(/"innertubeApiKey"\s*:\s*"([^"]+)"/i) ||
                            html.match(/key=([^"&?\/ ]+)/i);
        const innertubeApiKey = apiKeyMatch ? apiKeyMatch[1] : null;

        const clientVersionMatch = html.match(/"INNERTUBE_CLIENT_VERSION"\s*:\s*"([^"]+)"/i) || 
                                   html.match(/"clientVersion"\s*:\s*"([^"]+)"/i);
        const activeClientVersion = clientVersionMatch ? clientVersionMatch[1] : "2.20241101.01.00";

        console.log(`[PROXY] Initial token: ${continuationToken ? "found" : "null"}. API Key: ${innertubeApiKey ? "found" : "null"}. Client Version: ${activeClientVersion}`);

        if (continuationToken && innertubeApiKey && results.length < 1000) {
          let loopCount = 0;
          // Loop and load up to 1000 items (316 in user's playlist)
          while (continuationToken && results.length < 1000 && loopCount < 30) {
            loopCount++;
            console.log(`[PROXY] Pulling playlist continuation batch ${loopCount}. Accumulated count: ${results.length}`);
            try {
              const continuationUrl = `https://www.youtube.com/youtubei/v1/browse?key=${innertubeApiKey}`;
              const cResponse = await fetch(continuationUrl, {
                method: 'POST',
                headers: {
                  'Content-Type': 'application/json',
                  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                },
                body: JSON.stringify({
                  context: {
                    client: {
                      clientName: "WEB",
                      clientVersion: activeClientVersion,
                      originalUrl: url,
                      platform: "DESKTOP",
                      clientFormFactor: "UNKNOWN_FORM_FACTOR",
                    }
                  },
                  continuation: continuationToken
                })
              });

              if (!cResponse.ok) {
                console.log(`[PROXY] Continuation batch ${loopCount} request failed with level status: ${cResponse.status}`);
                break;
              }

              const cData = await cResponse.json();
              const pageVideoRenderers = findKeys(cData, 'playlistVideoRenderer');
              console.log(`[PROXY] Batch ${loopCount} fetched ${pageVideoRenderers.length} video candidates.`);

              let addedInThisPage = 0;
              for (const item of pageVideoRenderers) {
                if (!item || !item.videoId) continue;
                if (seenVideos.has(item.videoId)) continue;
                seenVideos.add(item.videoId);

                let title = "Untitled Syllabus Unit";
                if (item.title) {
                  if (Array.isArray(item.title.runs) && item.title.runs[0]?.text) {
                    title = item.title.runs[0].text;
                  } else if (typeof item.title.simpleText === 'string') {
                    title = item.title.simpleText;
                  }
                }

                let duration = "15:00";
                if (item.lengthText?.simpleText) {
                  duration = item.lengthText.simpleText;
                } else if (item.lengthSeconds) {
                  const sec = parseInt(item.lengthSeconds, 10);
                  if (!isNaN(sec)) {
                    const h = Math.floor(sec / 3600);
                    const m = Math.floor((sec % 3600) / 60);
                    const s = sec % 60;
                    duration = h > 0 
                      ? `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}` 
                      : `${m}:${String(s).padStart(2, '0')}`;
                  }
                }

                results.push({
                  id: item.videoId,
                  videoId: item.videoId,
                  title,
                  duration,
                  thumbnail: `https://img.youtube.com/vi/${item.videoId}/hqdefault.jpg`,
                  url: `https://www.youtube.com/watch?v=${item.videoId}&list=${playlistId}`,
                });
                addedInThisPage++;
                if (results.length >= 1000) break;
              }

              if (addedInThisPage === 0) {
                console.log("[PROXY] Zero new videos added in this loop. Checking alternate structures or stopping pagination.");
              }

              // Locate next pages token recursively using our smart recursive finder
              continuationToken = findContinuationToken(cData);
              console.log(`[PROXY] Next continuation token loaded: ${continuationToken ? "yes" : "no"}`);
            } catch (err) {
              console.error("[PROXY] Continuation page retrieval caught error:", err);
              break;
            }
          }
        }

        // If no items extracted, try fallback videoRenderers (for custom mixing streams)
        if (results.length === 0) {
          const regularVideoRenderers = findKeys(ytInitialData, 'videoRenderer');
          for (const item of regularVideoRenderers) {
            if (!item || !item.videoId) continue;
            if (seenVideos.has(item.videoId)) continue;
            seenVideos.add(item.videoId);

            let title = "Untitled Syllabus Unit";
            if (item.title?.runs?.[0]?.text) {
              title = item.title.runs[0].text;
            }

            let duration = "15:00";
            if (item.lengthText?.simpleText) {
              duration = item.lengthText.simpleText;
            }

            results.push({
              id: item.videoId,
              videoId: item.videoId,
              title,
              duration,
              thumbnail: `https://img.youtube.com/vi/${item.videoId}/hqdefault.jpg`,
              url: `https://www.youtube.com/watch?v=${item.videoId}`,
            });
          }
        }

        if (results.length === 0) {
          console.log("[PROXY] Scraped 0 video elements natively. Engaging Invidious fallback.");
          
          const invidiousPlaylist = await getPlaylistViaInvidious(playlistId);
          if (invidiousPlaylist) {
            return res.json({
              title: invidiousPlaylist.title,
              isPlaylist: true,
              videos: invidiousPlaylist.videos
            });
          }

          console.log("[PROXY] Invidious fallback failed. Engaging official YouTube Data API recovery.");
          const apiFallback = await getPlaylistViaYouTubeAPI(playlistId);
          if (apiFallback) {
            return res.json({
              title: apiFallback.title,
              isPlaylist: true,
              videos: apiFallback.videos,
              isAiGenerated: false
            });
          }
          
          console.log("[PROXY] YouTube API fallback failed or no key provided. Engaging AI syllabus recovery.");
          const aiFallback = await getPlaylistFallbackViaAI(playlistId, url);
          if (aiFallback) {
            return res.json({
              title: aiFallback.title,
              isPlaylist: true,
              videos: aiFallback.videos,
              isAiGenerated: true
            });
          }
          
          return res.status(503).json({ error: "Failed to extract playlist. YouTube blocked the native request, and all fallbacks failed. Please add a YOUTUBE_API_KEY in Settings to enable reliable official extraction." });
        }

        return res.json({
          title: playlistTitle,
          isPlaylist: true,
          videos: results
        });
      } else if (videoId) {
        // Scrape watchers structure
        const ytInitialPlayerResponse = extractJsonBlock(html, 'ytInitialPlayerResponse =') || extractJsonBlock(html, 'ytInitialPlayerResponse=');
        
        let title = "Lecture Module";
        let duration = "12:00";

        if (ytInitialPlayerResponse?.videoDetails) {
          const details = ytInitialPlayerResponse.videoDetails;
          title = details.title || title;
          if (details.lengthSeconds) {
            const sec = parseInt(details.lengthSeconds, 10);
            if (!isNaN(sec)) {
              const h = Math.floor(sec / 3600);
              const m = Math.floor((sec % 3600) / 60);
              const s = sec % 60;
              duration = h > 0 
                ? `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}` 
                : `${m}:${String(s).padStart(2, '0')}`;
            }
          }
        } else {
          // Alternative: fetch YouTube oembed directly as backup
          try {
            const oResponse = await fetch(`https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=${videoId}&format=json`);
            if (oResponse.ok) {
              const oData = await oResponse.json();
              if (oData && oData.title) {
                title = oData.title;
              }
            }
          } catch (oe) {
            console.error("[ERROR] Failed oembed backup call:", oe);
          }
        }

        if (title === "Lecture Module") {
          console.log("[PROXY] YouTube scraping failed for videoId: " + videoId + ". Trying Invidious video API fallback...");
          const invidiousVideo = await getVideoViaInvidious(videoId);
          if (invidiousVideo) {
            title = invidiousVideo.title;
            duration = invidiousVideo.duration;
          }
        }

        return res.json({
          title,
          isPlaylist: false,
          videos: [
            {
              id: videoId,
              videoId: videoId,
              title,
              duration,
              thumbnail: `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`,
              url: url
            }
          ]
        });
      } else {
        return res.status(400).json({ error: "No valid YouTube playlistId or videoId matches were extracted." });
      }
    } catch (error: any) {
      console.error("[ERROR] Scraper encountered severe breakdown:", error);
      return res.status(500).json({ error: `Internal error parsing YouTube playlist metadata: ${error.message}` });
    }
  });

  // API router to fetch direct audio streams using open source Invidious API fallbacks
  app.get("/api/yt-stream", async (req, res) => {
    const { videoId } = req.query;
    if (!videoId || typeof videoId !== 'string') {
      return res.status(400).json({ error: "Missing videoId parameter" });
    }

    // A list of reliable public Invidious instances
    const instances = [
      "https://yewtu.be",
      "https://invidious.projectsegfau.lt",
      "https://invidious.privacydev.net",
      "https://invidious.lunar.icu",
      "https://invidious.no-logs.com",
      "https://inv.zzls.xyz"
    ];

    console.log(`[PROXY] Direct streaming raw audio bytes for videoId: ${videoId}`);

    for (const instance of instances) {
      // We try standard itag 140 (AAC 128kbps) or 251 (Opus 160kbps) proxied locally
      for (const itag of ["140", "251"]) {
        try {
          const streamUrl = `${instance}/latest_version?id=${videoId}&itag=${itag}&local=true`;
          console.log(`[PROXY] Attempting stream connection: ${streamUrl}`);
          
          const streamResponse = await fetch(streamUrl, {
            headers: {
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            }
          });

          if (streamResponse.ok) {
            const contentType = streamResponse.headers.get("content-type") || (itag === "140" ? "audio/mp4" : "audio/webm");
            const contentLength = streamResponse.headers.get("content-length");

            console.log(`[PROXY] Connected to stream for ${videoId} from ${instance} (itag: ${itag}). Content-Type: ${contentType}`);
            
            res.setHeader("Content-Type", contentType);
            if (contentLength) {
              res.setHeader("Content-Length", contentLength);
            }
            res.setHeader("Accept-Ranges", "bytes");

            const body = streamResponse.body;
            if (body) {
              if (typeof (body as any).pipe === 'function') {
                (body as any).pipe(res);
              } else {
                const reader = (body as any).getReader();
                try {
                  while (true) {
                    const { done, value } = await reader.read();
                    if (done) break;
                    res.write(value);
                  }
                } catch (streamErr) {
                  console.log("[PROXY] Stream piping interrupted:", streamErr.message || streamErr);
                } finally {
                  res.end();
                }
              }
              return; // Success! Stream started.
            }
          }
        } catch (err) {
          console.log(`[PROXY] Failed latest_version fetch for ${videoId} via ${instance} (itag: ${itag}):`, err.message || err);
        }
      }
    }

    return res.status(500).json({ error: "Failed to resolve playable audio stream from any public Invidious provider." });
  });

  // Vite middleware setup
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[SERVER] Full-Stack server running on Port: ${PORT}`);
  });
}

startServer();
