import React, { useState, useEffect } from 'react';
import { motion, useSpring, useTransform, AnimatePresence } from 'motion/react';

interface KineticHeadingProps {
  text: string;
  subtitle?: string;
  level?: 'h1' | 'h2' | 'h3' | 'h4';
  gradient?: 'cyan-purple' | 'emerald-cyan' | 'amber-rose' | 'violet-pink' | 'cyan-blue';
  interactiveHover?: boolean;
  glow?: boolean;
  className?: string;
  badgeText?: string;
  badgeType?: 'live' | 'hud' | 'system' | 'ai';
}

const gradients = {
  'cyan-purple': 'from-cyan-400 via-indigo-400 to-purple-400',
  'indigo-purple': 'from-indigo-400 via-purple-400 to-pink-400',
  'emerald-cyan': 'from-emerald-400 via-teal-300 to-cyan-400',
  'amber-rose': 'from-amber-400 via-rose-400 to-purple-400',
  'violet-pink': 'from-violet-400 via-fuchsia-400 to-pink-400',
  'cyan-blue': 'from-sky-300 via-cyan-400 to-indigo-400',
};

export const KineticHeading: React.FC<KineticHeadingProps> = ({
  text,
  subtitle,
  level = 'h1',
  gradient = 'cyan-purple',
  interactiveHover = true,
  glow = true,
  className = '',
  badgeText,
  badgeType = 'hud',
}) => {
  const [isHovered, setIsHovered] = useState(false);
  const words = text.split(' ');

  const Tag = level as React.ElementType;

  const sizeClasses = {
    h1: 'text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-extrabold tracking-tight',
    h2: 'text-2xl sm:text-3xl md:text-4xl font-bold tracking-tight',
    h3: 'text-xl sm:text-2xl md:text-3xl font-semibold tracking-tight',
    h4: 'text-lg sm:text-xl font-medium tracking-tight',
  }[level];

  return (
    <div className={`relative group/kinetic ${className}`}>
      {/* Optional Top Badge */}
      {badgeText && (
        <motion.div
          initial={{ opacity: 0, y: -8, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 0.4, ease: 'easeOut' }}
          className="mb-2 inline-flex items-center gap-1.5"
        >
          <KineticBadge text={badgeText} type={badgeType} />
        </motion.div>
      )}

      {/* Main Kinetic Heading */}
      <Tag
        onMouseEnter={() => interactiveHover && setIsHovered(true)}
        onMouseLeave={() => interactiveHover && setIsHovered(false)}
        className={`relative inline-block select-none ${sizeClasses}`}
      >
        <span className="sr-only">{text}</span>
        
        {/* Kinetic Words and Characters Container */}
        <span className="flex flex-wrap gap-x-[0.28em] gap-y-1 items-baseline" aria-hidden="true">
          {words.map((word, wordIdx) => {
            const letters = word.split('');
            return (
              <span key={wordIdx} className="inline-flex overflow-hidden py-1">
                {letters.map((char, charIdx) => {
                  const totalCharIndex = words.slice(0, wordIdx).join('').length + charIdx;
                  return (
                    <motion.span
                      key={charIdx}
                      initial={{ y: '110%', opacity: 0, rotateX: -45, filter: 'blur(8px)' }}
                      animate={{ 
                        y: '0%', 
                        opacity: 1, 
                        rotateX: 0, 
                        filter: 'blur(0px)',
                      }}
                      whileHover={interactiveHover ? {
                        y: -6,
                        scale: 1.15,
                        rotateZ: (charIdx % 2 === 0 ? 3 : -3),
                        transition: { type: 'spring', stiffness: 400, damping: 15 }
                      } : undefined}
                      transition={{
                        duration: 0.5,
                        delay: totalCharIndex * 0.025,
                        ease: [0.16, 1, 0.3, 1],
                      }}
                      className={`inline-block transition-colors duration-300 ${
                        glow ? 'drop-shadow-[0_0_12px_rgba(6,182,212,0.3)]' : ''
                      }`}
                    >
                      <span className={`bg-gradient-to-r ${gradients[gradient] || gradients['cyan-purple']} bg-clip-text text-transparent inline-block font-sans`}>
                        {char}
                      </span>
                    </motion.span>
                  );
                })}
              </span>
            );
          })}
        </span>

        {/* Ambient Holographic Scanline Highlight */}
        {glow && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: isHovered ? 0.6 : 0.2 }}
            className={`absolute -inset-x-4 -inset-y-2 bg-gradient-to-r ${gradients[gradient] || gradients['cyan-purple']} opacity-10 blur-xl -z-10 rounded-full transition-opacity duration-500`}
          />
        )}
      </Tag>

      {/* Subtitle with Kinetic Fade-In */}
      {subtitle && (
        <motion.p
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 0.75, y: 0 }}
          transition={{ duration: 0.6, delay: text.length * 0.02 + 0.1 }}
          className="mt-2 text-sm sm:text-base text-gray-300 font-light max-w-2xl leading-relaxed"
        >
          {subtitle}
        </motion.p>
      )}
    </div>
  );
};

/* Kinetic Animated Text / Paragraph */
interface KineticTextProps {
  text: string;
  className?: string;
  delay?: number;
  speed?: number;
  staggerWords?: boolean;
}

export const KineticText: React.FC<KineticTextProps> = ({
  text,
  className = '',
  delay = 0,
  staggerWords = true,
}) => {
  if (!staggerWords) {
    return (
      <motion.p
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay }}
        className={className}
      >
        {text}
      </motion.p>
    );
  }

  const words = text.split(' ');

  return (
    <p className={`inline-flex flex-wrap gap-x-1.5 gap-y-0.5 ${className}`}>
      {words.map((word, idx) => (
        <motion.span
          key={idx}
          initial={{ opacity: 0, y: 6, filter: 'blur(4px)' }}
          animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
          transition={{
            duration: 0.4,
            delay: delay + idx * 0.03,
            ease: 'easeOut',
          }}
          className="inline-block"
        >
          {word}
        </motion.span>
      ))}
    </p>
  );
};

/* Kinetic HUD Badge / Status Pill */
interface KineticBadgeProps {
  text: string;
  type?: 'live' | 'hud' | 'system' | 'ai' | 'warning' | 'success';
  className?: string;
  onClick?: () => void;
}

export const KineticBadge: React.FC<KineticBadgeProps> = ({
  text,
  type = 'hud',
  className = '',
  onClick,
}) => {
  const styles = {
    live: 'bg-rose-500/10 border-rose-500/30 text-rose-300 shadow-[0_0_12px_rgba(244,63,94,0.2)]',
    hud: 'bg-cyan-500/10 border-cyan-500/30 text-cyan-300 shadow-[0_0_12px_rgba(6,182,212,0.15)]',
    system: 'bg-violet-500/10 border-violet-500/30 text-violet-300 shadow-[0_0_12px_rgba(139,92,246,0.15)]',
    ai: 'bg-amber-500/10 border-amber-500/30 text-amber-300 shadow-[0_0_12px_rgba(245,158,11,0.2)]',
    warning: 'bg-orange-500/10 border-orange-500/30 text-orange-300',
    success: 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300 shadow-[0_0_12px_rgba(16,185,129,0.15)]',
  }[type];

  const dotColors = {
    live: 'bg-rose-400 shadow-[0_0_8px_#f43f5e]',
    hud: 'bg-cyan-400 shadow-[0_0_8px_#06b6d4]',
    system: 'bg-violet-400 shadow-[0_0_8px_#8b5cf6]',
    ai: 'bg-amber-400 shadow-[0_0_8px_#f59e0b]',
    warning: 'bg-orange-400',
    success: 'bg-emerald-400 shadow-[0_0_8px_#10b981]',
  }[type];

  return (
    <motion.div
      whileHover={{ scale: 1.05, y: -1 }}
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-mono tracking-wider border backdrop-blur-md transition-all cursor-default select-none ${styles} ${className}`}
    >
      <span className="relative flex h-2 w-2">
        <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${dotColors}`} />
        <span className={`relative inline-flex rounded-full h-2 w-2 ${dotColors}`} />
      </span>
      <span className="uppercase tracking-widest text-[10px] font-semibold">{text}</span>
    </motion.div>
  );
};

/* Kinetic Numeric Counter Ticker */
interface KineticCounterProps {
  value: number;
  duration?: number;
  prefix?: string;
  suffix?: string;
  decimals?: number;
  className?: string;
}

export const KineticCounter: React.FC<KineticCounterProps> = ({
  value,
  duration = 1.5,
  prefix = '',
  suffix = '',
  decimals = 0,
  className = '',
}) => {
  const [displayValue, setDisplayValue] = useState(0);

  useEffect(() => {
    let startTimestamp: number | null = null;
    const startValue = displayValue;
    const endValue = value;

    const step = (timestamp: number) => {
      if (!startTimestamp) startTimestamp = timestamp;
      const progress = Math.min((timestamp - startTimestamp) / (duration * 1000), 1);
      // Ease out expo formula
      const easeOut = progress === 1 ? 1 : 1 - Math.pow(2, -10 * progress);
      const current = startValue + (endValue - startValue) * easeOut;
      setDisplayValue(current);

      if (progress < 1) {
        requestAnimationFrame(step);
      }
    };

    requestAnimationFrame(step);
  }, [value, duration]);

  return (
    <span className={`font-mono inline-flex items-baseline ${className}`}>
      {prefix && <span className="opacity-70 text-[0.8em] mr-0.5">{prefix}</span>}
      <motion.span
        key={Math.round(displayValue)}
        initial={{ y: 2, opacity: 0.8 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.1 }}
      >
        {displayValue.toFixed(decimals)}
      </motion.span>
      {suffix && <span className="opacity-70 text-[0.8em] ml-0.5">{suffix}</span>}
    </span>
  );
};
