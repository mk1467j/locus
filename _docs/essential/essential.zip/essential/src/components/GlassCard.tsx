import React from 'react';
import { motion, HTMLMotionProps } from 'motion/react';
import { cn } from '@/lib/utils';
import { useSettings } from '@/context/SettingsContext';

interface GlassCardProps extends HTMLMotionProps<"div"> {
  children: React.ReactNode;
  className?: string;
  hoverable?: boolean;
}

export function GlassCard({ children, className, hoverable = false, ...props }: GlassCardProps) {
  const { animationIntensity } = useSettings();
  
  const isAnimDisabled = animationIntensity === 'none';
  const duration = animationIntensity === 'slow' ? 0.75 : (animationIntensity === 'high' ? 0.25 : 0.45);
  
  return (
    <motion.div
      initial={{ opacity: 0, y: isAnimDisabled ? 0 : 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: isAnimDisabled ? 0 : duration, ease: [0.25, 1, 0.5, 1] }}
      className={cn(
        "glass-panel rounded-3xl",
        hoverable && "glass-panel-hover cursor-pointer",
        className
      )}
      style={{
        padding: className?.includes('p-') ? undefined : 'var(--density-padding, 24px)',
        gap: className?.includes('gap-') ? undefined : 'var(--density-gap, 16px)',
        ...props.style
      }}
      {...props}
    >
      {children}
    </motion.div>
  );
}
