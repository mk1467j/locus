import { Play, Pause, RotateCcw, X, Minimize2, Maximize2, Coffee, Sparkles, Pin, PinOff } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useSettings } from '@/context/SettingsContext';
import { safeJsonParse } from '@/lib/utils';

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence, useMotionValue } from 'motion/react';

export function FloatingPomodoro() {
  const { user, guestUser } = useAuth();
  const { batterySaver } = useSettings();
  const currentUserId = user?.id || guestUser?.id || 'guest_default';

  const [isOpen, setIsOpen] = useState(() => {
    const saved = localStorage.getItem('studyvibe_pomodoro_open');
    return safeJsonParse(saved, false);
  });

  const isOpenRef = useRef(isOpen);
  useEffect(() => {
    isOpenRef.current = isOpen;
  }, [isOpen]);
  
  const [isMinimized, setIsMinimized] = useState(() => {
    const saved = localStorage.getItem('studyvibe_pomodoro_minimized');
    return safeJsonParse(saved, false);
  });

  const [position, setPosition] = useState(() => {
    const saved = localStorage.getItem('studyvibe_pomodoro_position');
    const defaultPos = { x: (typeof window !== 'undefined' ? window.innerWidth : 1000) - 340, y: 120 };
    return safeJsonParse(saved, defaultPos);
  });

  const dragX = useMotionValue(position.x);
  const dragY = useMotionValue(position.y);

  useEffect(() => {
    dragX.set(position.x);
    dragY.set(position.y);
  }, [position.x, position.y, dragX, dragY]);

  const [isPinned, setIsPinned] = useState(() => {
    const saved = localStorage.getItem('studyvibe_pomodoro_pinned');
    return safeJsonParse(saved, false);
  });

  // Helpers & Configurations
  type FocusModeId = 'pomodoro' | 'deep_work' | 'quick_focus' | 'long_sprint' | 'short_break' | 'long_break';

  const MODE_DURATIONS: Record<FocusModeId, number> = {
    pomodoro: 25 * 60,
    deep_work: 50 * 60,
    quick_focus: 15 * 60,
    long_sprint: 90 * 60,
    short_break: 5 * 60,
    long_break: 15 * 60,
  };

  const MODE_ACCENTS: Record<FocusModeId, string> = {
    pomodoro: '#8b5cf6',
    deep_work: '#f59e0b',
    quick_focus: '#06b6d4',
    long_sprint: '#10b881',
    short_break: '#ec4899',
    long_break: '#d946ef',
  };

  // Pomodoro States
  const [timeLeft, setTimeLeft] = useState(() => {
    const saved = localStorage.getItem('studyvibe_focus_time_left');
    return saved !== null ? parseInt(saved, 10) : 25 * 60;
  });
  const [isActive, setIsActive] = useState(() => {
    return localStorage.getItem('studyvibe_focus_is_active') === 'true';
  });
  const [isConfirmingEnd, setIsConfirmingEnd] = useState(false);
  const [currentMode, setCurrentMode] = useState<FocusModeId>(() => {
    return (localStorage.getItem('studyvibe_focus_active_mode') || 'pomodoro') as FocusModeId;
  });
  const [completedSessions, setCompletedSessions] = useState(() => {
    return safeJsonParse<number>(localStorage.getItem('studyvibe_pomodoro_sessions'), 0);
  });

  const containerRef = useRef<HTMLDivElement>(null);
  
  // Viewport clamping effect to make sure widget position is always visible
  useEffect(() => {
    const clampPosition = () => {
      setPosition(prev => {
        const w = isMinimized ? 200 : 320;
        const h = isMinimized ? 80 : 450;
        const maxX = window.innerWidth - w - 10;
        const maxY = window.innerHeight - h - 10;
        let newX = Math.max(10, Math.min(prev.x, maxX));
        let newY = Math.max(10, Math.min(prev.y, maxY));
        return { x: newX, y: newY };
      });
    };

    clampPosition();
    window.addEventListener('resize', clampPosition);
    return () => window.removeEventListener('resize', clampPosition);
  }, [isMinimized]);

  // Listen to mobile stage centerpiece controller custom events
  useEffect(() => {
    const handleToggle = () => {
      setIsOpen(prev => !prev);
    };
    window.addEventListener('toggle-pomodoro-widget', handleToggle);
    return () => {
      window.removeEventListener('toggle-pomodoro-widget', handleToggle);
    };
  }, []);

  // Sync state to localStorage
  useEffect(() => {
    localStorage.setItem('studyvibe_pomodoro_open', JSON.stringify(isOpen));
  }, [isOpen]);

  // Show timer when active countdown starts
  const prevIsActive = useRef(isActive);
  useEffect(() => {
    if (isActive && !prevIsActive.current) {
      setIsOpen(true);
    }
    prevIsActive.current = isActive;
  }, [isActive]);

  useEffect(() => {
    localStorage.setItem('studyvibe_pomodoro_minimized', JSON.stringify(isMinimized));
  }, [isMinimized]);

  useEffect(() => {
    localStorage.setItem('studyvibe_pomodoro_pinned', JSON.stringify(isPinned));
  }, [isPinned]);

  useEffect(() => {
    localStorage.setItem('studyvibe_pomodoro_sessions', JSON.stringify(completedSessions));
  }, [completedSessions]);

  // Automatically end active focus session when user closes/reloads the website
  useEffect(() => {
    const handleBeforeUnload = () => {
      const activeStr = localStorage.getItem('studyvibe_focus_is_active');
      if (activeStr === 'true') {
        const savedTimeLeftStr = localStorage.getItem('studyvibe_focus_time_left');
        const savedMode = (localStorage.getItem('studyvibe_focus_active_mode') || 'pomodoro') as FocusModeId;
        const savedTimestampStr = localStorage.getItem('studyvibe_focus_saved_timestamp');
        
        if (savedTimeLeftStr) {
          const parsedTimeLeft = parseInt(savedTimeLeftStr, 10);
          if (!isNaN(parsedTimeLeft)) {
            let remainingVal = parsedTimeLeft;
            if (savedTimestampStr) {
              const savedTimestamp = parseInt(savedTimestampStr, 10);
              if (!isNaN(savedTimestamp)) {
                const timeElapsed = Math.floor((Date.now() - savedTimestamp) / 1000);
                remainingVal = Math.max(0, parsedTimeLeft - timeElapsed);
              }
            }
            
            const max = MODE_DURATIONS[savedMode] || 25 * 60;
            const elapsedSeconds = max - remainingVal;
            
            if (elapsedSeconds > 0) {
              const logsKey = `studyvibe_focus_sessions_logs_${currentUserId}`;
              const savedLogs = localStorage.getItem(logsKey);
              let logsList = safeJsonParse<any[]>(savedLogs, []);
              
              const getModeLabel = (mode: FocusModeId) => {
                switch (mode) {
                  case 'pomodoro': return 'Pomodoro';
                  case 'deep_work': return 'Deep Work';
                  case 'quick_focus': return 'Quick Focus';
                  case 'long_sprint': return 'Long Sprint';
                  case 'short_break': return 'Short Break';
                  case 'long_break': return 'Long Break';
                  default: return 'Study Session';
                }
              };
              
              const freshLog = {
                id: `session_unload_${Date.now()}`,
                modeId: savedMode,
                modeName: `${getModeLabel(savedMode)} (Auto Ended)`,
                durationSeconds: elapsedSeconds,
                completedAt: new Date().toISOString()
              };
              
              const nextLogs = [freshLog, ...logsList];
              localStorage.setItem(logsKey, JSON.stringify(nextLogs));
            }
            
            // Reset standard focus keys
            localStorage.setItem('studyvibe_focus_is_active', 'false');
            localStorage.setItem('studyvibe_focus_time_left', max.toString());
            localStorage.setItem('studyvibe_focus_saved_timestamp', Date.now().toString());
          }
        }
      }
    };

    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, [currentUserId]);

  // Synchronize with standard focus timer keys in real-time
  useEffect(() => {
    const syncFromStorage = () => {
      const savedTimeLeftStr = localStorage.getItem('studyvibe_focus_time_left');
      const savedIsActive = localStorage.getItem('studyvibe_focus_is_active') === 'true';
      const savedMode = (localStorage.getItem('studyvibe_focus_active_mode') || 'pomodoro') as FocusModeId;
      const savedTimestampStr = localStorage.getItem('studyvibe_focus_saved_timestamp');

      if (savedTimeLeftStr) {
        const parsedTimeLeft = parseInt(savedTimeLeftStr, 10);
        if (!isNaN(parsedTimeLeft)) {
          if (savedIsActive && savedTimestampStr) {
            const savedTimestamp = parseInt(savedTimestampStr, 10);
            if (!isNaN(savedTimestamp)) {
              const timeElapsed = Math.floor((Date.now() - savedTimestamp) / 1000);
              const remainingVal = Math.max(0, parsedTimeLeft - timeElapsed);
              setTimeLeft(remainingVal);
              setIsActive(remainingVal > 0 ? savedIsActive : false);
              setCurrentMode(savedMode);
              if (remainingVal > 0 && savedIsActive && !isOpenRef.current) {
                setIsOpen(true);
                setIsMinimized(true);
              }
              return;
            }
          }
          setTimeLeft(parsedTimeLeft);
          setIsActive(savedIsActive);
          setCurrentMode(savedMode);
          if (savedIsActive && !isOpenRef.current) {
            setIsOpen(true);
            setIsMinimized(true);
          }
        }
      }
    };

    syncFromStorage();
    const handleShortcut = () => {
      setIsOpen(prev => {
        const nextState = !prev;
        if (nextState) {
          setIsMinimized(false);
        }
        return nextState;
      });
    };

    window.addEventListener('storage', syncFromStorage);
    window.addEventListener('focus', syncFromStorage);
    window.addEventListener('studyvibe-timer-sync', syncFromStorage);
    window.addEventListener('studyvibe-shortcut-pomodoro', handleShortcut as EventListener);
    
    return () => {
      window.removeEventListener('storage', syncFromStorage);
      window.removeEventListener('focus', syncFromStorage);
      window.removeEventListener('studyvibe-timer-sync', syncFromStorage);
      window.removeEventListener('studyvibe-shortcut-pomodoro', handleShortcut as EventListener);
    };
  }, []);

  // Pomodoro countdown effect
  useEffect(() => {
    let interval: any = null;
    let ticks = 0;
    
    if (isActive && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((time: number) => {
          const next = time - 1;
          ticks++;
          
          // In battery saver mode, skip excessive localStorage I/O writes (only save every 5 seconds)
          if (!batterySaver || ticks % 5 === 0) {
            localStorage.setItem('studyvibe_focus_time_left', next.toString());
            localStorage.setItem('studyvibe_focus_saved_timestamp', Date.now().toString());
          }
          
          return next;
        });
      }, 1000);
    } else if (timeLeft === 0 && isActive) {
      setIsActive(false);
      localStorage.setItem('studyvibe_focus_is_active', 'false');
      localStorage.setItem('studyvibe_focus_saved_timestamp', Date.now().toString());
      window.dispatchEvent(new CustomEvent('studyvibe-timer-sync'));
      handleSessionComplete();
    }
    return () => clearInterval(interval);
  }, [isActive, timeLeft, batterySaver]);

  const handleSessionComplete = () => {
    const isFocusSession = ['pomodoro', 'deep_work', 'quick_focus', 'long_sprint'].includes(currentMode);
    if (isFocusSession) {
      const nextSessions = completedSessions + 1;
      setCompletedSessions(nextSessions);
      if (nextSessions % 4 === 0) {
        setMode('long_break');
      } else {
        setMode('short_break');
      }
    } else {
      setMode('pomodoro');
    }
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioCtx.createOscillator();
      const gainNode = audioCtx.createGain();
      oscillator.type = 'sine';
      oscillator.frequency.setValueAtTime(523.25, audioCtx.currentTime); // C5
      oscillator.frequency.exponentialRampToValueAtTime(783.99, audioCtx.currentTime + 0.3); // G5
      gainNode.gain.setValueAtTime(0.08, audioCtx.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.4);
      oscillator.connect(gainNode);
      gainNode.connect(audioCtx.destination);
      oscillator.start();
      oscillator.stop(audioCtx.currentTime + 0.5);
    } catch (e) {
      console.warn('Audio Context failed', e);
    }
  };

  const setMode = (mode: FocusModeId) => {
    const duration = MODE_DURATIONS[mode] || 25 * 60;

    setCurrentMode(mode);
    setIsActive(false);
    setTimeLeft(duration);

    localStorage.setItem('studyvibe_focus_active_mode', mode);
    localStorage.setItem('studyvibe_focus_time_left', duration.toString());
    localStorage.setItem('studyvibe_focus_is_active', 'false');
    localStorage.setItem('studyvibe_focus_saved_timestamp', Date.now().toString());
    window.dispatchEvent(new CustomEvent('studyvibe-timer-sync'));
  };

  const toggleTimer = () => {
    const nextActive = !isActive;
    setIsActive(nextActive);
    localStorage.setItem('studyvibe_focus_is_active', nextActive.toString());
    localStorage.setItem('studyvibe_focus_saved_timestamp', Date.now().toString());
    window.dispatchEvent(new CustomEvent('studyvibe-timer-sync'));
  };

  const resetTimer = () => {
    setIsActive(false);
    setMode(currentMode);
  };

  const endSessionEarly = () => {
    const max = MODE_DURATIONS[currentMode] || 25 * 60;
    if (!isActive && timeLeft === max) {
      return;
    }
    
    if (!isConfirmingEnd) {
      setIsConfirmingEnd(true);
      setTimeout(() => setIsConfirmingEnd(false), 3000);
      return;
    }
    
    setIsConfirmingEnd(false);
    
    const elapsedSeconds = max - timeLeft;
    
    if (elapsedSeconds > 0) {
      try {
        const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
          const oscillator = audioCtx.createOscillator();
          const gainNode = audioCtx.createGain();
          oscillator.type = 'sine';
          oscillator.frequency.setValueAtTime(880, audioCtx.currentTime); // A5
          oscillator.frequency.exponentialRampToValueAtTime(1320, audioCtx.currentTime + 0.15); // E6
          gainNode.gain.setValueAtTime(0.3, audioCtx.currentTime);
          gainNode.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.6);
          oscillator.connect(gainNode);
          gainNode.connect(audioCtx.destination);
          oscillator.start();
          oscillator.stop(audioCtx.currentTime + 0.85);
        } catch (e) {}

        const logsKey = `studyvibe_focus_sessions_logs_${currentUserId}`;
        const savedLogs = localStorage.getItem(logsKey);
        let logsList = safeJsonParse<any[]>(savedLogs, []);
        const freshLog = {
          id: `session_early_widget_${Date.now()}`,
          modeId: currentMode,
          modeName: `${activeModeLabel()} (Ended Early)`,
          durationSeconds: elapsedSeconds,
          completedAt: new Date().toISOString()
        };
        const nextLogs = [freshLog, ...logsList];
        localStorage.setItem(logsKey, JSON.stringify(nextLogs));
      }
      
      setIsActive(false);
      setTimeLeft(max);
      localStorage.setItem('studyvibe_focus_is_active', 'false');
      localStorage.setItem('studyvibe_focus_time_left', max.toString());
      localStorage.setItem('studyvibe_focus_saved_timestamp', Date.now().toString());
      window.dispatchEvent(new CustomEvent('studyvibe-timer-sync'));
  };

  const handleDragEnd = () => {
    const updatedPos = { x: dragX.get(), y: dragY.get() };
    setPosition(updatedPos);
    localStorage.setItem('studyvibe_pomodoro_position', JSON.stringify(updatedPos));
  };


  const formatTime = (seconds: number) => {
    const min = Math.floor(seconds / 60);
    const sec = seconds % 60;
    return `${min.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`;
  };

  const activeModeLabel = () => {
    switch (currentMode) {
      case 'pomodoro': return 'Pomodoro';
      case 'deep_work': return 'Deep Work';
      case 'quick_focus': return 'Quick Focus';
      case 'long_sprint': return 'Long Sprint';
      case 'short_break': return 'Short Break';
      case 'long_break': return 'Long Break';
      default: return 'Study Session';
    }
  };

  const getPercentageLeft = () => {
    const max = MODE_DURATIONS[currentMode] || 25 * 60;
    return (timeLeft / max) * 100;
  };

  if (!isOpen) {
    return null;
  }

  const width = isMinimized ? 200 : 320;
  const height = isMinimized ? 80 : 450;
  const dynamicDragConstraints = {
    left: 10,
    right: Math.max(10, window.innerWidth - width - 10),
    top: 10,
    bottom: Math.max(10, window.innerHeight - height - (window.innerWidth < 768 ? 90 : 15))
  };

  const isDraggable = !isPinned;

  const dragProps = isDraggable ? {
    drag: true,
    dragMomentum: false,
    dragElastic: 0.1,
    onDragEnd: handleDragEnd
  } : {};

  return (
    <motion.div
      ref={containerRef}
      style={{ left: 0, top: 0, x: dragX, y: dragY, position: 'fixed' as const }}
      {...dragProps}
      dragConstraints={dynamicDragConstraints}
      className="fixed z-[80] select-none"
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ type: 'spring', stiffness: 300, damping: 25 }}
    >
      <AnimatePresence mode="wait">
        {isMinimized ? (
          // Minimized Compact Capsule UI
          <motion.div
            key="minimized"
            layoutId="pomodoro-widget"
            className={`flex items-center gap-3 bg-[#050510]/35 backdrop-blur-md border border-white/10 px-4 py-2.5 rounded-full shadow-[0_12px_32px_rgba(0,0,0,0.4)] group hover:border-brand-purple/40 transition-colors max-w-xs font-mono ${
              isDraggable ? 'cursor-grab active:cursor-grabbing' : 'cursor-default'
            }`}
            style={{ touchAction: 'none' }}
          >
            {/* Play progress arc */}
            <div 
              onPointerDown={(e) => e.stopPropagation()}
              className="relative w-8 h-8 flex items-center justify-center flex-shrink-0"
            >
              <svg className="absolute inset-0 w-full h-full transform -rotate-90">
                <circle cx="16" cy="16" r="14" stroke="rgba(255,255,255,0.05)" strokeWidth="2.5" fill="transparent" />
                <circle 
                  cx="16" cy="16" r="14" 
                  stroke={MODE_ACCENTS[currentMode] || '#8b5cf6'} 
                  strokeWidth="2.5" 
                  fill="transparent" 
                  strokeDasharray={2 * Math.PI * 14}
                  strokeDashoffset={2 * Math.PI * 14 - (getPercentageLeft() / 100) * (2 * Math.PI * 14)}
                  strokeLinecap="round"
                />
              </svg>
              {isActive ? (
                <Pause className="w-3.5 h-3.5 text-white absolute cursor-pointer hover:text-brand-purple transition-colors" onClick={toggleTimer} />
              ) : (
                <Play className="w-3.5 h-3.5 text-white translate-x-0.5 absolute cursor-pointer hover:text-brand-purple transition-colors" onClick={toggleTimer} />
              )}
            </div>

            <div className="flex flex-col select-none pr-1">
              <span className="text-[10px] text-gray-400 capitalize truncate w-14 leading-none">{currentMode.includes('break') ? 'break' : 'focusing'}</span>
              <span 
                className="timer-display-font font-semibold text-white mt-0.5"
                style={{ '--timer-base-size': '0.875rem' } as React.CSSProperties}
              >
                {formatTime(timeLeft)}
              </span>
            </div>

            <div 
              onPointerDown={(e) => e.stopPropagation()}
              className="flex items-center gap-1.5 border-l border-white/10 pl-2"
            >
              <button 
                onClick={() => setIsMinimized(false)}
                className="p-1 rounded-md hover:bg-white/5 text-gray-400 hover:text-white transition-colors cursor-pointer"
                title="Expand Controls"
              >
                <Maximize2 className="w-3 h-3" />
              </button>
            </div>
          </motion.div>
        ) : (
          // Expanded Immersive Glass Pomodoro
          <motion.div
            key="expanded"
            layoutId="pomodoro-widget"
            className={`w-80 glass-panel bg-[#050510]/35 backdrop-blur-md border border-white/10 rounded-3xl p-6 shadow-[0_20px_50px_rgba(0,0,0,0.7)] group hover:border-brand-purple/30 text-white font-sans flex flex-col relative overflow-hidden ${
              isDraggable ? 'cursor-grab active:cursor-grabbing' : 'cursor-default'
            }`}
            style={{ touchAction: 'none' }}
          >
            {/* Visual Cinematic Highlight Backdrop */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-brand-purple/10 rounded-full blur-2xl pointer-events-none" />
            
            {/* Drag Handle & Controls */}
            <div className="flex items-center justify-between pb-4 border-b border-white/5 mb-4 select-none">
              <div className="flex items-center gap-2">
                <div className={`w-2 h-2 rounded-full ${isActive ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} style={{ backgroundColor: MODE_ACCENTS[currentMode] }} />
                <span className="font-serif italic text-sm text-gray-200">Focus Core</span>
              </div>

              <div 
                onPointerDown={(e) => e.stopPropagation()}
                className="flex items-center gap-1.5" 
                onClick={(e) => e.stopPropagation() /* stop drag on click */}
              >
                <button
                  onClick={() => setIsPinned(!isPinned)}
                  className={`p-1.5 rounded-lg hover:bg-white/5 transition-colors cursor-pointer ${isPinned ? 'text-brand-purple' : 'text-gray-400 hover:text-white'}`}
                  title={isPinned ? 'Unlock Dragging' : 'Lock Widget Dragging'}
                >
                  {isPinned ? <PinOff className="w-3.5 h-3.5" /> : <Pin className="w-3.5 h-3.5" />}
                </button>
                <button
                  onClick={() => setIsMinimized(true)}
                  className="p-1.5 rounded-lg hover:bg-white/5 text-gray-400 hover:text-white transition-colors cursor-pointer"
                  title="Minimize Widget"
                >
                  <Minimize2 className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => setIsOpen(false)}
                  className="p-1.5 rounded-lg hover:bg-white/5 text-gray-400 hover:text-rose-400 transition-colors cursor-pointer"
                  title="Close Widget"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Timer Modes Selector Grid */}
            <div 
              onPointerDown={(e) => e.stopPropagation()}
              className="grid grid-cols-3 gap-1.5 bg-white/5 p-1 rounded-2xl border border-white/10 mb-5 select-none" 
              onClick={(e) => e.stopPropagation()}
            >
              {(['pomodoro', 'deep_work', 'quick_focus', 'long_sprint', 'short_break', 'long_break'] as const).map((m) => (
                <button
                  key={m}
                  onClick={() => setMode(m)}
                  style={{ borderColor: currentMode === m ? `${MODE_ACCENTS[m]}40` : 'transparent' }}
                  className={`py-1.5 text-[9px] uppercase font-bold tracking-wider rounded-xl transition-all font-mono leading-none border truncate cursor-pointer ${
                    currentMode === m
                      ? 'bg-white/10 text-white shadow-md'
                      : 'text-gray-400 hover:text-white hover:bg-white/5'
                  }`}
                  title={m.replace('_', ' ')}
                >
                  {m === 'pomodoro' ? 'pomo' : m === 'deep_work' ? 'deep' : m === 'quick_focus' ? 'micro' : m === 'long_sprint' ? 'sprint' : m === 'short_break' ? 'short' : 'long'}
                </button>
              ))}
            </div>

            {/* Circular countdown visualization */}
            <motion.div 
              className="relative w-40 h-40 mx-auto mb-5 flex items-center justify-center select-none" 
              onClick={(e) => e.stopPropagation()}
              onPointerDown={(e) => e.stopPropagation()}
              animate={isActive ? { scale: [1, 1.03, 1] } : { scale: 1 }}
              transition={isActive ? { repeat: Infinity, duration: 4, ease: "easeInOut" } : {}}
            >
              <svg 
                className="absolute inset-0 w-full h-full"
                style={{ 
                  transform: 'rotate(-90deg) scale(var(--timer-size-scale, 1))',
                  transformOrigin: 'center',
                  transition: 'transform 0.3s cubic-bezier(0.16, 1, 0.3, 1)'
                }}
              >
                <circle cx="80" cy="80" r="74" stroke="rgba(255, 255, 255, 0.04)" strokeWidth="4.5" fill="transparent" />
                <circle 
                  cx="80" cy="80" r="74" 
                  stroke="url(#widgetPurpleGlowGrad)" 
                  strokeWidth="5" 
                  fill="transparent" 
                  strokeDasharray={2 * Math.PI * 74}
                  strokeDashoffset={2 * Math.PI * 74 - (getPercentageLeft() / 100) * (2 * Math.PI * 74)}
                  strokeLinecap="round"
                  className="transition-all duration-300 ease-out"
                />
                <defs>
                  <linearGradient id="widgetPurpleGlowGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor={MODE_ACCENTS[currentMode] || '#8b5cf6'} />
                    <stop offset="100%" stopColor={currentMode.includes('break') ? '#059669' : '#6366f1'} />
                  </linearGradient>
                </defs>
              </svg>

              {/* Centered Timer text */}
              <div className="absolute inset-0 flex flex-col items-center justify-center select-none pointer-events-none">
                <span 
                  className="timer-display-font text-white" 
                  style={{ 
                    color: MODE_ACCENTS[currentMode],
                    '--timer-base-size': '2rem'
                  } as React.CSSProperties}
                >
                  {formatTime(timeLeft)}
                </span>
                
                {/* Labels in normal block flow to guarantee zero overlap */}
                <div className="mt-2.5 flex flex-col items-center">
                  <span className="text-[8.5px] font-mono text-gray-500 uppercase tracking-widest leading-none">
                    {activeModeLabel()}
                  </span>
                </div>
              </div>
            </motion.div>

            {/* Dynamic session metadata */}
            <div 
              onPointerDown={(e) => e.stopPropagation()}
              className="text-center mb-5 px-4 select-none"
            >
              <div className="flex items-center justify-between text-xs font-mono text-gray-400 bg-white/5 border border-white/5 py-2 px-3.5 rounded-xl">
                <span>Completed Rounds</span>
                <span className="font-medium text-sm font-semibold" style={{ color: MODE_ACCENTS[currentMode] }}>{completedSessions}</span>
              </div>
            </div>

            {/* Control buttons */}
            <div 
              onPointerDown={(e) => e.stopPropagation()}
              className="flex gap-2.5 justify-center select-none" 
              onClick={(e) => e.stopPropagation()}
            >
              <button 
                onClick={resetTimer}
                className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 text-gray-400 hover:text-white hover:bg-white/10 transition-colors flex items-center justify-center cursor-pointer shrink-0"
                title="Reset timer"
              >
                <RotateCcw className="w-4 h-4" />
              </button>

              <button 
                onClick={toggleTimer}
                className="flex-1 py-2.5 px-3 rounded-xl bg-brand-purple hover:bg-brand-purple/90 text-white font-mono text-[10px] uppercase tracking-wider font-bold transition-all flex items-center justify-center gap-1 shadow-[0_4px_15px_rgba(139,92,246,0.2)] active:scale-[0.98] cursor-pointer"
              >
                {isActive ? (
                  <>
                    <Pause className="w-3 h-3 fill-white" /> Pause
                  </>
                ) : (
                  <>
                    <Play className="w-3 h-3 fill-white translate-x-0.5" /> Start
                  </>
                )}
              </button>

              <button 
                onClick={endSessionEarly}
                className={`px-3 py-2.5 rounded-xl border font-mono text-[9px] uppercase font-bold tracking-widest transition-all duration-300 shrink-0 ${
                  isConfirmingEnd 
                    ? 'border-rose-500 bg-rose-600 text-white animate-pulse' 
                    : 'border-rose-500/20 bg-rose-950/20 text-rose-400 hover:bg-rose-500/25 active:scale-95'
                }`}
                title={isConfirmingEnd ? "Click again to confirm ending early" : "End active focus session early and log progress"}
              >
                {isConfirmingEnd ? "Sure?" : "End"}
              </button>
            </div>
            
            <p className="text-[8px] font-mono text-gray-500 text-center mt-4 uppercase tracking-widest">Studying at studyvibe.co</p>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
