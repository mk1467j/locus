import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence, useMotionValue } from 'motion/react';
import { 
  Play, Pause, SkipForward, SkipBack, Minimize2, Maximize2, 
  Volume2, VolumeX, X, Music, Radio, Sparkles, Pin, PinOff, 
  Shuffle, Repeat, AlertCircle, Trash2
} from 'lucide-react';
import { useMusic } from '@/context/MusicContext';
import { safeJsonParse } from '@/lib/utils';

declare global {
  interface Window {
    onYouTubeIframeAPIReady?: () => void;
    YT?: any;
  }
}

export function FloatingMusicPlayer() {
  const {
    playlists,
    activePlaylistId,
    currentTrackIndex,
    currentTrack,
    isPlaying,
    isMuted,
    volume,
    progress,
    duration,
    currentTime,
    isShuffle,
    isLoop,
    playTrack,
    togglePlay,
    nextTrack,
    prevTrack,
    toggleMute,
    setVolume,
    seek,
    toggleShuffle,
    toggleLoop,
    setYoutubePlayer,
    ytPlayer,
    isVideoMode,
    setIsVideoMode,
    isOpen,
    setIsOpen,
    isMinimized,
    setIsMinimized,
    deleteTrack
  } = useMusic();

  const [position, setPosition] = useState(() => {
    const saved = localStorage.getItem('studyvibe_music_position');
    return safeJsonParse(saved, { x: 740, y: 150 });
  });

  const dragX = useMotionValue(position.x);
  const dragY = useMotionValue(position.y);

  useEffect(() => {
    dragX.set(position.x);
    dragY.set(position.y);
  }, [position.x, position.y, dragX, dragY]);

  const [isPinned, setIsPinned] = useState(() => {
    const saved = localStorage.getItem('studyvibe_music_pinned');
    return safeJsonParse(saved, false);
  });

  const isPlayingRef = useRef(isPlaying);
  const isVideoModeRef = useRef(isVideoMode);
  const currentTrackRef = useRef(currentTrack);

  useEffect(() => {
    isPlayingRef.current = isPlaying;
  }, [isPlaying]);

  useEffect(() => {
    isVideoModeRef.current = isVideoMode;
  }, [isVideoMode]);

  useEffect(() => {
    currentTrackRef.current = currentTrack;
  }, [currentTrack]);

  const containerRef = useRef<HTMLDivElement>(null);
  const ytContainerRef = useRef<HTMLDivElement>(null);

  // Sync window boundaries on screen size modifications
  useEffect(() => {
    const clampPositionOnResize = () => {
      setPosition(prev => {
        const width = !isOpen ? 150 : isMinimized ? 220 : 230;
        const height = !isOpen ? 45 : isMinimized ? (isVideoMode ? 170 : 50) : 210;

        const maxX = window.innerWidth - width - 10;
        const maxY = window.innerHeight - height - 10;

        const clampedX = Math.max(10, Math.min(prev.x, Math.max(10, maxX)));
        const clampedY = Math.max(10, Math.min(prev.y, Math.max(10, maxY)));

        return { x: clampedX, y: clampedY };
      });
    };

    window.addEventListener('resize', clampPositionOnResize);
    return () => window.removeEventListener('resize', clampPositionOnResize);
  }, [isOpen, isMinimized, isVideoMode]);

  // Mobile stages listener
  useEffect(() => {
    const handleToggle = () => {
      setIsOpen(!isOpen);
    };
    window.addEventListener('toggle-music-widget', handleToggle);
    return () => {
      window.removeEventListener('toggle-music-widget', handleToggle);
    };
  }, [isOpen]);

  // Show player on music playback start
  const prevIsPlaying = useRef(isPlaying);
  useEffect(() => {
    if (isPlaying && !prevIsPlaying.current) {
      setIsOpen(true);
    }
    prevIsPlaying.current = isPlaying;
  }, [isPlaying]);

  // Store active pinned state locally
  useEffect(() => {
    localStorage.setItem('studyvibe_music_pinned', JSON.stringify(isPinned));
  }, [isPinned]);

  const createYTPlayer = () => {
    if (!ytContainerRef.current) return;
    if (!window.YT || !window.YT.Player) return;
    
    const id = currentTrackRef.current?.url || '';
    if (!id) return;

    // Reuse existing YT player frame to completely bypass browser interaction / autoplay policy restarts
    if (ytPlayer) {
      try {
        const isPlaylist = currentTrackRef.current?.source === 'youtube' && (id.length > 11 || id.startsWith('PL') || currentTrackRef.current?.duration === 'Playlist');
        
        if (isPlaylist) {
          if (typeof ytPlayer.cuePlaylist === 'function') {
            ytPlayer.cuePlaylist({ list: id });
          }
        } else {
          if (isPlayingRef.current) {
            if (typeof ytPlayer.loadVideoById === 'function') {
              ytPlayer.loadVideoById(id);
            }
          } else {
            if (typeof ytPlayer.cueVideoById === 'function') {
              ytPlayer.cueVideoById(id);
            }
          }
        }
        return;
      } catch (err) {
        console.warn("Retrying YouTube player frame reconstruction:", err);
      }
    }

    try {
      ytContainerRef.current.innerHTML = '<div id="youtube-player-element" style="width: 100%; height: 100%;"></div>';

      const isPlaylist = currentTrackRef.current?.source === 'youtube' && (id.length > 11 || id.startsWith('PL') || currentTrackRef.current?.duration === 'Playlist');

      new window.YT.Player('youtube-player-element', {
        height: '100%',
        width: '100%',
        videoId: isPlaylist ? '' : id,
        playerVars: {
          autoplay: isPlayingRef.current ? 1 : 0,
          controls: 0,
          disablekb: 1,
          fs: 0,
          modestbranding: 1,
          rel: 0,
          showinfo: 0,
          ...(isPlaylist ? { listType: 'playlist', list: id } : {})
        },
        events: {
          onReady: (event: any) => {
            setYoutubePlayer(event.target);
            try {
              if (typeof event.target.setPlaybackQuality === 'function') {
                event.target.setPlaybackQuality(isVideoModeRef.current ? 'medium' : 'small');
              }
            } catch (err) {}
            if (isPlayingRef.current) {
              if (typeof event.target.playVideo === 'function') {
                event.target.playVideo();
              }
            }
          },
          onStateChange: (event: any) => {
            const endedState = window.YT?.PlayerState?.ENDED ?? 0;
            if (event.data === endedState) {
              nextTrack();
            }
          }
        }
      });
    } catch (err) {
      console.error("YouTube Player setup exception:", err);
    }
  };

  // Safe pre-loader
  useEffect(() => {
    const initYoutubeAPI = () => {
      if (!window.YT || !window.YT.Player) {
        if (!document.getElementById('youtube-iframe-api-script')) {
          const tag = document.createElement('script');
          tag.id = 'youtube-iframe-api-script';
          tag.src = "https://www.youtube.com/iframe_api";
          const firstScriptTag = document.getElementsByTagName('script')[0];
          firstScriptTag.parentNode?.insertBefore(tag, firstScriptTag);
        }

        const oldAPIReady = window.onYouTubeIframeAPIReady;
        window.onYouTubeIframeAPIReady = () => {
          if (oldAPIReady) oldAPIReady();
          createYTPlayer();
        };
      } else {
        createYTPlayer();
      }
    };

    if (currentTrack?.source === 'youtube') {
      initYoutubeAPI();
    }
  }, [currentTrack]);

  // Precise gesture accumulator drag end handler (eliminates side-snapping jumping bugs)
  const handleDragEnd = () => {
    const updatedPos = { x: dragX.get(), y: dragY.get() };
    setPosition(updatedPos);
    localStorage.setItem('studyvibe_music_position', JSON.stringify(updatedPos));
  };

  const width = !isOpen ? 150 : isMinimized ? 220 : 230;
  const height = !isOpen ? 45 : isMinimized ? (isVideoMode ? 170 : 50) : 210;
  const dynamicDragConstraints = {
    left: 10,
    right: Math.max(10, window.innerWidth - width - 10),
    top: 10,
    bottom: Math.max(10, window.innerHeight - height - (window.innerWidth < 768 ? 90 : 15))
  };

  // Time formatter
  const formatTime = (secs: number) => {
    if (isNaN(secs) || secs === Infinity) return '--:--';
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  const isDraggable = !isPinned;
  const trackEmoji = currentTrack?.cover || '🎵';
  const isSpotify = currentTrack?.source === 'spotify';
  const isYoutubeTrack = currentTrack?.source === 'youtube';

  return (
    <>
      <AnimatePresence>
        {currentTrack && (
          <motion.div
            ref={containerRef}
            drag={isDraggable}
            dragMomentum={false}
            dragElastic={0.1}
            dragConstraints={dynamicDragConstraints}
            style={{ 
              position: 'fixed' as const,
              left: 0, 
              top: 0,
              x: dragX,
              y: dragY,
              zIndex: 100,
              opacity: isOpen ? 1 : 0,
              pointerEvents: isOpen ? 'auto' : 'none'
            }}
            onDragEnd={handleDragEnd}
            className="select-none flex flex-col items-center gap-1.5"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ 
              opacity: isOpen ? 1 : 0, 
              scale: isOpen ? 1 : 0.95 
            }}
            transition={{ type: 'spring', stiffness: 300, damping: 25 }}
          >
            {/* Shared Non-Unmounting YouTube Player Iframe nested inside the draggable card. 
                Utilizes a persistent aspect-stable hidden wrapper relative to the player layout 
                to eliminate browser-specific reloading behaviors when styling/positioning switches. */}
            {isYoutubeTrack && (
              <div 
                className={
                  isVideoMode && !isMinimized
                    ? "w-[200px] h-[113px] rounded-2xl overflow-hidden border border-white/10 bg-black mx-auto shrink-0 z-20 relative shadow-2xl mb-2.5 mt-1 pointer-events-auto block"
                    : isVideoMode && isMinimized
                      ? "w-[200px] h-[113px] rounded-2xl overflow-hidden border border-white/10 bg-black mx-auto shrink-0 z-20 relative shadow-2xl pointer-events-auto block"
                      : "absolute w-[1px] h-[1px] opacity-10 overflow-hidden pointer-events-none z-10 left-[10px] top-[10px]"
                }
              >
                <div 
                  ref={ytContainerRef}
                  className={isVideoMode ? "w-[200px] h-[113px]" : "w-[1px] h-[1px]"}
                />
              </div>
            )}

            <AnimatePresence mode="wait">
              {isMinimized ? (
                // Compact playing pod
                <motion.div
                  key="music-minimized"
                  layoutId="music-player-widget"
                  className={`flex items-center gap-2 bg-black/45 backdrop-blur-2xl border border-white/10 px-2.5 py-2 rounded-full shadow-[0_15px_40px_rgba(0,0,0,0.8)] group hover:border-indigo-500/30 font-mono border-solid ${
                    isDraggable ? 'cursor-grab active:cursor-grabbing' : 'cursor-default'
                  }`}
                  style={{ touchAction: 'none' }}
                >
                  {/* Circular Record-style rotating track artwork cover */}
                  <motion.div
                    animate={{ rotate: isPlaying ? 360 : 0 }}
                    transition={isPlaying ? { duration: 12, repeat: Infinity, ease: "linear" } : { duration: 0 }}
                    className="w-7 h-7 rounded-full overflow-hidden border border-white/10 relative flex-shrink-0 bg-indigo-500/10 flex items-center justify-center select-none"
                  >
                    {isYoutubeTrack ? (
                      <img 
                        src={`https://img.youtube.com/vi/${currentTrack.url}/mqdefault.jpg`} 
                        alt="Cover" 
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover rounded-full"
                      />
                    ) : trackEmoji.startsWith('http') || trackEmoji.includes('/') ? (
                      <img 
                        src={trackEmoji} 
                        alt="Cover" 
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover rounded-full"
                      />
                    ) : (
                      <span className="text-xs">{trackEmoji || '🎵'}</span>
                    )}
                  </motion.div>

                  <div className="flex flex-col select-none pr-1 w-20 overflow-hidden text-left">
                    <span className="text-[6.5px] text-indigo-400 capitalize truncate leading-none tracking-widest font-bold font-mono">ACOUSTIC</span>
                    <span className="text-[9.5px] font-semibold text-white truncate mt-0.5 leading-tight">{currentTrack?.title || 'StudyVibe'}</span>
                  </div>

                  <div className="flex items-center gap-1 border-l border-white/5 pl-1.5" onPointerDown={(e) => e.stopPropagation()}>
                    <button
                      onClick={togglePlay}
                      disabled={isSpotify}
                      className={`p-0.5 rounded-full hover:bg-white/5 text-white transition-colors ${isSpotify ? 'opacity-30 cursor-not-allowed' : ''}`}
                    >
                      {isPlaying ? <Pause className="w-3 h-3 fill-white" /> : <Play className="w-3 h-3 fill-white translate-x-0.5" />}
                    </button>
                    
                    <button 
                      onClick={() => setIsMinimized(false)}
                      className="p-0.5 rounded-md hover:bg-white/5 text-gray-400 hover:text-white transition-colors"
                    >
                      <Maximize2 className="w-2.5 h-2.5" />
                    </button>
                  </div>
                </motion.div>
              ) : (
                // Expanded elegant transparent glassmorphism player
                <motion.div
                  key="music-expanded"
                  layoutId="music-player-widget"
                  className={`w-[230px] bg-[#0c0c0e]/40 backdrop-blur-2xl border border-white/10 rounded-[28px] p-3.5 shadow-[0_20px_50px_rgba(0,0,0,0.8)] group hover:border-brand-primary/20 text-white font-sans flex flex-col relative overflow-hidden ${
                    isDraggable ? 'cursor-grab active:cursor-grabbing' : 'cursor-default'
                  }`}
                  style={{ touchAction: 'none' }}
                >
                  <div className="absolute top-0 right-0 w-20 h-20 bg-brand-indigo/15 rounded-full blur-xl pointer-events-none" />

                  {/* Header controllers */}
                  <header 
                    className={`flex items-center justify-between pb-1.5 border-b border-white/5 mb-2.5 select-none ${
                      isDraggable ? 'cursor-grab active:cursor-grabbing' : 'cursor-default'
                    }`}
                  >
                    <div className="flex items-center gap-1">
                      <Radio className="w-3 h-3 text-indigo-400 animate-pulse" />
                      <span className="font-serif italic text-[10px] text-gray-300">Scholar Deck</span>
                    </div>

                    <div className="flex items-center gap-0.5" onClick={(e) => e.stopPropagation()} onPointerDown={(e) => e.stopPropagation()}>
                      <button
                        onClick={() => setIsPinned(!isPinned)}
                        className={`p-1 rounded-lg hover:bg-white/5 transition-colors ${isPinned ? 'text-indigo-400' : 'text-gray-400 hover:text-white'}`}
                        title={isPinned ? 'Unpin' : 'Pin Widget'}
                      >
                        {isPinned ? <PinOff className="w-2.5 h-2.5" /> : <Pin className="w-2.5 h-2.5" />}
                      </button>
                      <button
                        onClick={() => setIsMinimized(true)}
                        className="p-1 rounded-lg hover:bg-white/5 text-gray-400 hover:text-white transition-colors"
                      >
                        <Minimize2 className="w-2.5 h-2.5" />
                      </button>
                      <button
                        onClick={() => setIsOpen(false)}
                        className="p-1 rounded-lg hover:bg-white/5 text-gray-400 hover:text-rose-400 transition-colors"
                      >
                        <X className="w-2.5 h-2.5" />
                      </button>
                    </div>
                  </header>

                  {/* Body details */}
                  <div className="select-none" onClick={(e) => e.stopPropagation()} onPointerDown={(e) => e.stopPropagation()}>
                    
                    {/* Audio Only vs Video Play Toggle Switch (Only for YouTube tracks) */}
                    {isYoutubeTrack && (
                      <div className="flex bg-white/5 border border-white/10 rounded-xl p-0.5 mb-3 mx-auto w-[180px]">
                        <button
                          onClick={() => setIsVideoMode(false)}
                          className={`flex-1 py-1 rounded-lg text-[9px] font-mono uppercase tracking-wider font-bold transition-all cursor-pointer ${
                            !isVideoMode 
                              ? 'bg-indigo-600 text-white shadow' 
                              : 'text-gray-400 hover:text-white'
                          }`}
                        >
                          Audio Only
                        </button>
                        <button
                          onClick={() => setIsVideoMode(true)}
                          className={`flex-1 py-1 rounded-lg text-[9px] font-mono uppercase tracking-wider font-bold transition-all cursor-pointer ${
                            isVideoMode 
                              ? 'bg-indigo-600 text-white shadow' 
                              : 'text-gray-400 hover:text-white'
                          }`}
                        >
                          Video Play
                        </button>
                      </div>
                    )}

                    {/* YouTube Audio Cover (only in audio mode) */}
                    {isYoutubeTrack && !isVideoMode && (
                      <div className="py-1.5 flex flex-col items-center select-none">
                        <div className="w-12 h-12 rounded-xl overflow-hidden border border-white/10 mb-2 shadow-sm">
                          <img 
                            src={`https://img.youtube.com/vi/${currentTrack.url}/mqdefault.jpg`} 
                            alt="Song Cover" 
                            className="w-full h-full object-cover" 
                            referrerPolicy="no-referrer"
                          />
                        </div>
                      </div>
                    )}

                    {/* Non-YouTube cover details */}
                    {!isYoutubeTrack && (
                      <div className="py-2 flex flex-col items-center select-none">
                        {trackEmoji.startsWith('http') ? (
                          <div className="w-9 h-9 rounded-xl overflow-hidden border border-white/10 mb-2 shadow-sm">
                            <img src={trackEmoji} alt="Song Cover" className="w-full h-full object-cover" />
                          </div>
                        ) : (
                          <div className="w-8 h-8 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-base mb-2 shadow-sm">
                            {trackEmoji}
                          </div>
                        )}
                        <span className="text-[11px] font-semibold text-white truncate w-full block px-1.5 leading-tight text-center">{currentTrack?.title || 'StudyVibe Sync'}</span>
                        <div className="flex items-center gap-1.5 justify-center mt-0.5 select-none">
                          <span className="text-[8px] text-gray-500 font-mono block truncate max-w-[120px] text-center">{currentTrack?.artist || 'Scholar Music'}</span>
                          {currentTrack && (
                            <button
                              onClick={() => deleteTrack(activePlaylistId, currentTrack.id)}
                              className="text-gray-500 hover:text-rose-400 transition-colors p-0.5 rounded cursor-pointer"
                              title="Delete track from playlist"
                            >
                              <Trash2 className="w-2.5 h-2.5" />
                            </button>
                          )}
                        </div>
                      </div>
                    )}

                    {/* YouTube text details */}
                    {isYoutubeTrack && (
                      <div className="pb-1.5 text-center select-none">
                        <span className="text-[11px] font-semibold text-white truncate w-full block px-1 leading-tight">{currentTrack?.title}</span>
                        <div className="flex items-center gap-1.5 justify-center mt-0.5 select-none">
                          <span className="text-[8px] text-gray-400 font-mono block truncate max-w-[150px]">{currentTrack?.artist}</span>
                          {currentTrack && (
                            <button
                              onClick={() => deleteTrack(activePlaylistId, currentTrack.id)}
                              className="text-gray-500 hover:text-rose-400 transition-colors p-0.5 rounded cursor-pointer"
                              title="Delete track from playlist"
                            >
                              <Trash2 className="w-2.5 h-2.5" />
                            </button>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Spotify Embed integration */}
                    {isSpotify && currentTrack && (
                      <div className="mb-2.5 select-none" onClick={(e) => e.stopPropagation()}>
                        <iframe
                          src={`https://open.spotify.com/embed/${currentTrack.url.replace('spotify:', '').replace(/:/g, '/')}`}
                          width="100%"
                          height="80"
                          frameBorder="0"
                          allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"
                          loading="lazy"
                          className="rounded-xl border border-white/10 bg-neutral-900"
                        />
                        <div className="p-1 bg-emerald-500/5 border border-emerald-500/10 rounded-lg mt-1 flex items-center gap-1">
                          <AlertCircle className="w-2.5 h-2.5 text-emerald-400 shrink-0" />
                          <span className="text-[7px] font-mono text-emerald-400">Controls are managed directly in the Spotify card.</span>
                        </div>
                      </div>
                    )}

                    {/* Equalizer Wave (hidden for Spotify) */}
                    {!isSpotify && (
                      <div className="flex justify-center items-end gap-0.5 h-3 mb-2.5">
                        {Array.from({ length: 12 }).map((_, i) => {
                          const h = 2 + (i % 3) * 3 + ((i * 2) % 3) * 2;
                          return (
                            <motion.div
                              key={i}
                              animate={{
                                height: isPlaying && !isSpotify
                                  ? [h, Math.floor(h / 3), h + 2, h]
                                  : [h, h]
                              }}
                              transition={{
                                duration: 0.8 + (i % 3) * 0.15,
                                repeat: Infinity,
                                ease: 'easeInOut'
                              }}
                              className="w-0.5 rounded-full bg-indigo-500/50"
                              style={{ height: `${h}px` }}
                            />
                          );
                        })}
                      </div>
                    )}
                  </div>

                  {/* Audio slider timeline */}
                  {!isSpotify && (
                    <div className="space-y-0.5 mb-2.5 select-none font-mono text-left" onClick={(e) => e.stopPropagation()}>
                      <div 
                        className="w-full h-1 bg-white/10 hover:bg-white/15 rounded-full overflow-hidden cursor-pointer relative"
                        onClick={(e) => {
                          const rect = e.currentTarget.getBoundingClientRect();
                          const percent = ((e.clientX - rect.left) / rect.width) * 100;
                          seek(percent);
                        }}
                      >
                        <div className="h-full bg-indigo-500 rounded-full" style={{ width: `${progress}%` }} />
                      </div>
                      <div className="flex justify-between items-center text-[7.5px] text-gray-500 leading-none">
                        <span>{formatTime(currentTime)}</span>
                        <span>{formatTime(duration)}</span>
                      </div>
                    </div>
                  )}

                  {/* Player Buttons */}
                  {!isSpotify && (
                    <div className="flex items-center justify-between border-t border-b border-white/5 py-1 mb-2.5 select-none" onClick={(e) => e.stopPropagation()}>
                      <button
                        onClick={toggleShuffle}
                        className={`p-1 rounded-lg hover:bg-white/5 transition-all ${isShuffle ? 'text-indigo-400' : 'text-gray-550 hover:text-white'}`}
                      >
                        <Shuffle className="w-3 h-3" />
                      </button>

                      <div className="flex items-center gap-2">
                        <button 
                          onClick={prevTrack}
                          className="p-1 rounded-lg hover:bg-white/5 text-gray-400 hover:text-white transition-colors"
                        >
                          <SkipBack className="w-3.5 h-3.5" />
                        </button>

                        <button 
                          onClick={togglePlay}
                          className="w-7 h-7 rounded-full bg-white text-black hover:scale-105 active:scale-95 transition-all flex items-center justify-center shadow-sm cursor-pointer"
                        >
                          {isPlaying ? <Pause className="w-3 h-3 fill-black" /> : <Play className="w-3 h-3 fill-black translate-x-0.5" />}
                        </button>

                        <button 
                          onClick={nextTrack}
                          className="p-1 rounded-lg hover:bg-white/5 text-gray-400 hover:text-white transition-colors"
                        >
                          <SkipForward className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <button
                        onClick={toggleLoop}
                        className={`p-1 rounded-lg hover:bg-white/5 transition-all ${isLoop ? 'text-indigo-400' : 'text-gray-550 hover:text-white'}`}
                      >
                        <Repeat className="w-3 h-3" />
                      </button>
                    </div>
                  )}

                  {/* Volume controllers */}
                  <div className="flex items-center gap-1.5 select-none" onClick={(e) => e.stopPropagation()}>
                    <button 
                      onClick={toggleMute}
                      className="text-indigo-400 hover:text-white transition-colors cursor-pointer"
                    >
                      {isMuted ? <VolumeX className="w-3 h-3" /> : <Volume2 className="w-3 h-3" />}
                    </button>
                    <input 
                      type="range"
                      min="0"
                      max="100"
                      value={volume}
                      onChange={(e) => setVolume(Number(e.target.value))}
                      className="flex-1 accent-indigo-500 bg-white/10 rounded-lg appearance-auto cursor-pointer h-1"
                    />
                    <span className="text-[8px] font-mono text-gray-500 w-5 text-right">{volume}%</span>
                  </div>

                  <p className="text-[6.5px] font-mono text-gray-500 text-center mt-2 uppercase tracking-widest leading-relaxed">StudyVibe Acoustic Sync</p>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
