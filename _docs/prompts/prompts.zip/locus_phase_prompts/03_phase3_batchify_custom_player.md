# PHASE 3 — Batchify Hub, `youtube-playlist` Edge Function & Unified LOCUS Custom Study Player

## Startup Protocol
Read `AGENT_RULES.md`, `PROGRESS.md`, and Sections 7 & 10.3 of `_docs/LOCUS_Project_Bible_v2.pdf`.
Inspect `_docs/essential/server.ts` (lines 1–915) and `_docs/essential/src/pages/Batch.tsx` strictly as behavioral references for the playlist extraction waterfall and study-player hooks (do NOT copy Express or legacy Firebase/localStorage code).

## Interconnections
- **Consumes:**
  - Phase 1 `batches`, `batch_videos`, `video_notes`, `revision_queue` tables & `locus-media` Storage bucket.
  - Phase 2 `useWorkspaceStore`, `WorkspaceSwitcher`, `GlassCard`, `SPRING_HERO` (`layoutId`), and theme tokens.
- **Exposes to Downstream Phases:**
  - `supabase/functions/youtube-playlist/index.ts` (free ₹0 playlist extraction).
  - `src/stores/usePlayerStore.ts`: manages active video, playback time, speed, A–B loop, `isMiniPlayer` (Floating PiP), `pauseForPomodoro()` (called by Phase 5's Pomodoro timer), and `isPdfSplitOpen` (mounts Phase 4's `<PdfStudio compact />`).
  - Route query params `/batches/$batchId?v=$videoId&t=$sec` (used by Phase 6's `ExamRevisionQueue` deep-links!).

## Detailed Implementation Requirements

### 1. Supabase Edge Function (`supabase/functions/youtube-playlist/index.ts`)
Build a clean Deno TypeScript Edge Function accepting `POST { urlOrId: string, pageToken?: string }` with CORS headers and returning `{ title, channelTitle, thumbnailUrl, isPlaylist, videos: [{ youtubeId, title, durationSec, position, thumbnailUrl }], nextPageToken }`:
- **Tier 1 (Primary — Official YouTube Data API v3):** If `YOUTUBE_API_KEY` secret is set, call `playlists` (1 unit) + paginated `playlistItems` (1 unit per 50 videos) + `videos.list?part=contentDetails` (1 unit per 50 videos) to get real ISO-8601 durations cleanly.
- **Tier 2 (Zero-Key Fallback — Native YouTube HTML + InnerTube Continuation):** Port the exact `ytInitialData` (`playlistMetadataRenderer` + `playlistVideoRenderer`) + `INNERTUBE_API_KEY` + `continuationToken` `youtubei/v1/browse` pagination loop from `_docs/essential/server.ts` (lines 537–805, up to 1,000 videos); use YouTube `oembed` for single videos.
- **Tier 3 (Secondary Fallback — Healthy Invidious Mirrors):** Port dynamic mirror loading from `api.invidious.io/instances.json` (`server.ts` lines 313–505).
- **STRICTLY OMIT Tier 4 (Fake AI Syllabus Fallback):** Never fabricate fake video lists; return a clear, actionable error if all 3 real tiers fail.

### 2. Batchify Overview (`src/pages/Batches.tsx`)
- **Built-In In-Batchify Workspace Switcher:** Embed `<WorkspaceSwitcher variant="compact" />` directly inside the Batchify header so users can switch between `Upgrade Yourself`, `CIE`, `Exam`, or custom workspaces *without leaving Batchify*.
- **Active Workspace First + "Show Other Workspaces' Batches":** Shows batches matching `activeWorkspaceId` first, with a toggleable section revealing batches from other workspaces and 1-tap **"Pin to Current Workspace"** (`workspace_ids[]` array append in Postgres).
- **Import & Upload Modals:** Paste any public YouTube playlist/video URL (calls `youtube-playlist` Edge Function and saves to `batches` + `batch_videos`), OR upload personal lecture `.mp4` files to `locus-media/{uid}/videos/...`.
- **Hero Shared-Element Transition:** Clicking a batch card triggers `layoutId={`batch-hero-${batch.id}`}` morphing cleanly into `/batches/$batchId`.

### 3. Unified LOCUS Custom Study Player (`src/components/player/` & `src/pages/BatchPlayer.tsx`)
Build ONE glassmorphic player shell (`LocusPlayer.tsx`) driving BOTH `YouTubeEngine.tsx` (official YouTube IFrame Player API) and `Html5Engine.tsx` (native `<video>` for Supabase Storage videos):
- **Zero-Cost Clean YouTube Presentation (`CLEAN_EMBED_MODE` boolean toggle, default `true`):**
  - **Thumbnail Facade:** Shows high-res poster + custom glass Play button + **"Resume from X:XX?"** pill (`Resume` / `From Start`). Clicking Play invokes `player.playVideo()` synchronously inside the `onClick` handler for iOS/Android autoplay compatibility.
  - **Uncropped 300% Vertical-Overflow Wrapper:** Outer `relative aspect-video w-full overflow-hidden rounded-2xl bg-black`; inner `pointer-events-none absolute -top-[100%] left-0 h-[300%] w-full`. Keeps 100% of the 16:9 lecture uncropped while pushing YouTube's top title/Share bar and bottom "More videos" shelf completely out of view.
  - **Bottom-Right YouTube Attribution Badge:** Clean clickable `YouTube` badge in the bottom-right corner opening the source YouTube video in a new tab.
  - **0.5s End-Screen Interception:** Poll/monitor remaining time and intercept ~0.5s before `YT.PlayerState.ENDED` to pause and display a clean LOCUS **"Up Next / Replay"** glass overlay instead of YouTube's recommendation grid.
- **Productivity Controls & Gestures:**
  - Slim auto-hiding bottom bar: Play/Pause (`Space`/`K`), scrub bar with hover timestamp and **clickable colored pins** for Timestamp Notes & Exam Flags, Speed (`0.75x`–`2x`, `<`/`>`), `CC` toggle, Volume (`M`), Theater (`T`), Fullscreen (`F`).
  - **Pin Timestamp Note (`N`):** Stamps `[MM:SS]` into the right-side `video_notes` editor (with optional "Auto-pause while typing" toggle, resuming on `Ctrl+Enter`).
  - **Flag to Exam Revision Queue (`R`):** One tap creates a `revision_queue` entry with `deep_link: /batches/${batchId}?v=${videoId}&t=${Math.floor(currentTime)}`.
  - **A–B Concept Loop (`[` sets A, `]` sets B, `\` clears):** Loops smoothly between A and B until cleared.
  - **Linked PDF Split-Peek (`P`):** Opens a right-hand slot rendering the lecture's `linked_material_id` (shows clean placeholder slot now; Phase 4 drops `<PdfStudio compact />` right in).
  - **15s Auto-Save & 90% Auto-Complete:** Saves `last_watched_sec` to Supabase `batch_videos` every 15s and on pause/`visibilitychange`; marks `is_completed = true` at 90%.
  - **Mobile Touch Gestures:** Press-and-hold anywhere -> temporary `2x` speed (releases back to previous speed); double-tap left/right -> `-10s` / `+10s` with ripple feedback; swipe down -> shrinks smoothly into persistent draggable **Floating Mini-Player (`MiniPlayer.tsx`)** that stays alive across routes and workspace switches.
  - **Responsive Layout:** Mobile portrait `< 768px` uses `sticky top-0 z-30 w-full aspect-video` with tabbed Notes/Playlist/PDF scrolling underneath; Desktop `>= 1024px` uses ~68%/32% split view with `@tanstack/react-virtual` for 100+ video playlists.

## Verification Gate
- Run `npx tsc --noEmit` and `npm run build` -> 0 errors.
- Test `/batches` (in-Batchify workspace switch) and `/batches/$batchId?v=...&t=120` (auto-seek to 2:00, no top YouTube title bar, clickable bottom-right `YouTube` badge, `N` note pin, `R` exam flag, `[`/`]` A–B loop, `I` Floating PiP) at `1440px` and `390px`.
- Mark Phase 3 `[x]` in `PROGRESS.md` and stop.
