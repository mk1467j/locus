# PHASE 4 — Library, Cross-Workspace Notes/PDF Access & Unified Virtualized PDF Studio

## Startup Protocol
Read `AGENT_RULES.md`, `PROGRESS.md`, and Sections 4 & 8 of `_docs/LOCUS_Project_Bible_v2.pdf`.

## Interconnections
- **Consumes:**
  - Phase 1 `folders`, `materials`, `pdf_annotations`, `revision_queue` tables, private `locus-media` Storage bucket, and `dexie.ts` blob cache.
  - Phase 2 `useWorkspaceStore`, `AnimatePresence` curtain motion, and theme tokens.
- **Connects Back to Phase 3:** Mounts `<PdfStudio compact />` inside `BatchPlayer.tsx`'s **Linked PDF Split-Peek (`P`)** drawer.
- **Exposes to Phase 6:** Deep-link route `/library?materialId=$id&page=$page` for Exam Revision Queue jumps, plus offline-pinned PDF metadata for Dashboard Continue Learning.

## Detailed Implementation Requirements

### 1. Library & Cross-Workspace Notes/PDF System (`src/pages/Library.tsx` & `src/stores/useLibraryStore.ts`)
- **Normalized Store:** `foldersById`, `materialsById`, `activeMaterialId`, `showOtherWorkspaces` boolean.
- **Nested Folders & Unified Creation:** Create/rename/delete nested folders (`parent_id`), create Markdown notes (`NoteEditor.tsx` with clean live preview & auto-save), upload PDFs/images/audio/videos directly to Supabase Storage (`locus-media/{uid}/{type}/{id}.{ext}`, enforcing 50 MB max free-tier file check).
- **Active Workspace First + "Show Other Workspaces' Notes & PDFs" Curtain:**
  - Default view renders ONLY folders and materials where `workspace_ids` includes `activeWorkspaceId`.
  - Clicking **"Show Other Workspaces' Notes & PDFs (+N)"** opens an `AnimatePresence` spring accordion (`30ms` stagger per item) displaying items from all other workspaces grouped by workspace badge (`Upgrade Yourself`, `CIE`, `Exam`, etc.).
  - Every cross-workspace item supports two instant actions: **Open In-Place** (views/annotates immediately without leaving your current workspace) and **Pin to Current Workspace** (appends `activeWorkspaceId` to `workspace_ids[]` in Supabase with magnetic snap feedback — zero file duplication, all annotations automatically shared).
- **Offline Pinning (`dexie.ts`):** Toggle "Pin Offline" on any PDF to download and cache its binary `Blob` in `locus_offline_db.blobs`; when opening a PDF, check Dexie cache first for instant 0ms offline rendering before fetching a signed Storage URL.

### 2. Redesigned Unified Virtualized PDF Studio (`src/components/pdf/PdfStudio.tsx`)
Build ONE clean, modular PDF Studio (never duplicate viewers):
- **Web Worker + O(1) Virtualized Viewport (`VirtualPdfCanvas.tsx`):**
  - Configure `pdfjs-dist` worker cleanly for Vite (`GlobalWorkerOptions.workerSrc`).
  - Measure page aspect ratios and mount ONLY the visible page ±1 buffer using `@tanstack/react-virtual` (or IntersectionObserver) so RAM/GPU stays $O(1)$ even on 600-page engineering textbooks.
- **`ResizeObserver` Auto-Fit Width:** Observe the center stage container so every PDF page scales cleanly to fit width with **zero horizontal scrolling** on `390px` mobile and desktop split panes.
- **Desktop 3-Zone Studio Layout:**
  1. **Collapsible Left Rail** (collapsed by default for maximum reading width): virtualized page thumbnails + PDF Table of Contents outline.
  2. **Center Reading Stage + Auto-Hiding Floating Bottom Glass Annotation Dock:** Select, Highlighter, Pen (with color/thickness), Sticky Comment, Eraser, Undo/Redo, Zoom, Page Jump.
  3. **Collapsible Right Context Drawer:** Per-page comments, linked Batchify lecture timestamp jumps, and Exam Revision Queue pins.
- **Mobile Layout (`< 768px`):** Edge-to-edge fit-width canvas, slim top header (Back, Title, `p. X / Y`, Offline Pin), thumb-zone bottom tool pill, and swipe-up notes/comments `BottomSheet`.
- **Eye-Safe 3-Mode Reading Filter (`300ms` cross-fade):** **Original**, **Warm Sepia** (`sepia(0.32) contrast(0.96) brightness(0.95)`), and **OLED Dark Invert** (`invert(0.92) hue-rotate(180deg)`) so white textbooks stay effortless at 2 AM.
- **Lazy Ink/Highlight Overlay & Exam Revision Bridge:**
  - Load the lightweight SVG/Canvas drawing overlay ONLY when Highlight or Pen mode is toggled on; persist debounced strokes/highlights/comments to `pdf_annotations`.
  - Selecting text or placing a pin offers 1-tap **"Send to Exam Revision Queue"** creating a `revision_queue` item with `deep_link: /library?materialId=${materialId}&page=${pageNumber}`.

### 3. Wire Into Phase 3 `BatchPlayer.tsx`
Replace the Phase 3 Split-Peek (`P`) placeholder with `<PdfStudio materialId={activeVideo.linked_material_id} compact />` and allow linking/unlinking any Library PDF directly from the lecture player.

## Verification Gate
- Run `npx tsc --noEmit` and `npm run build` -> 0 errors.
- Test `/library` (active-first view, expanding "Show Other Workspaces", 1-tap Pin, opening a PDF, switching Original/Sepia/OLED, drawing & highlighting, sending to Revision Queue, offline pinning) and `/batches/$id` Split-Peek (`P`) at `1440px` and `390px` (confirm 0px horizontal scroll on mobile).
- Mark Phase 4 `[x]` in `PROGRESS.md` and stop.
