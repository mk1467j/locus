# LOCUS — Phase-by-Phase AI Agent Prompt Suite

## Pre-Flight Folder Setup (Do This Once Before Phase 0)
Create a clean, empty directory `locus/` and place:
```text
locus/
└── _docs/
    ├── LOCUS_Project_Bible_v2.pdf
    ├── essential/                  # Unzipped from essential.zip (behavioral reference only)
    └── prompts/                    # Unzipped from LOCUS_Phase_Prompts.zip (these .md files)
```

## Golden Execution Protocol (Zero Drift, 100% Working Result)
1. **Fresh Chat Per Phase:** Start a brand-new session in Google Antigravity, Cline, or Cursor for EVERY phase (`00` -> `08`).
2. **Exact Trigger Message:** Tell your agent: *"Read `_docs/prompts/0X_phaseX_....md` completely and execute every requirement and verification gate without skipping anything."*
3. **Verify & Commit Before Advancing:** Personally test the running app in your browser at `1440px` desktop and `390px` mobile, verify `tsc --noEmit` and `npm run build` pass, and commit to Git (`git add -A && git commit -m "feat(phase-X): ..."`) before starting the next phase.

## Master Phase Interconnection Matrix

| File | Phase Scope | Reads From Earlier Phases | Exposes To Downstream Phases |
| :--- | :--- | :--- | :--- |
| `00_phase0_setup_lock.md` | Context Lock & Clean Repo Scaffold | Bible PDF + `essential/` | `AGENT_RULES.md`, `PROGRESS.md`, Vite 6 + React 19 + Tailwind v4 + Pure Supabase deps |
| `01_phase1_supabase_auth.md` | Pure Supabase SQL, Storage RLS & Auth | Phase 0 scaffold | 13 Postgres tables + InitPlan RLS + GIN `workspace_ids[]`, `locus-media` Storage RLS, `useAuthStore` (Google + Anon Guest `linkIdentity`), `dexie.ts` |
| `02_phase2_visual_soul_themes_motion.md` | Visual Soul: Dock, Workspaces, 42 Themes, 3D Icons & Screenplay Motion | Phase 1 `profiles` & `workspaces` | `DesktopDock`, `MobileBottomNav`, `TopHud`, `WorkspaceSwitcher`, `useWorkspaceStore`, `useThemeStore`, `<LocusIcon />`, `switchThemeWithIris`, `playThemeSfx` |
| `03_phase3_batchify_custom_player.md` | Batchify Hub, Edge Function & Unified Study Player | Phase 1 DB/Storage, Phase 2 Shell/Motion, `_docs/essential/server.ts` & `Batch.tsx` | `youtube-playlist` Edge Function, `LocusPlayer` + `usePlayerStore` (PiP, `pauseForPomodoro()`, Split-Peek `P` slot, `video_notes` & `revision_queue` writes) |
| `04_phase4_library_cross_workspace_pdf_studio.md` | Library, Cross-Workspace Access & Unified Virtualized PDF Studio | Phase 1 Storage/Dexie, Phase 2 Shell/Workspaces, Phase 3 `linked_material_id` | `PdfStudio` (mounted in Phase 3 Split-Peek `P`), `Library` + **"Show Other Workspaces"** + `workspace_ids[]` pinning, PDF highlights -> `revision_queue` |
| `05_phase5_global_music_draggable_widgets.md` | 100% Global Music Studio & Draggable Floating Widgets | Phase 1 Storage/Dexie, Phase 2 SFX, Phase 3 `pauseForPomodoro()`, `_docs/essential/` widgets | Global `useMusicStore` + Offline Web Audio Ambient Mixer, `FloatingMusicPlayer`, `FloatingPomodoro` (`usePomodoroStore` -> `focus_sessions`) |
| `06_phase6_dashboard_focus_tasks_revision.md` | Dashboard, Focus/Cinematic Mode, Tasks, Sticky Walls & Exam Queue | Phases 1–5 stores & tables | Editorial `Dashboard`, `Focus` & `StudyMode` (milestone halo), `Tasks`, `StickyWalls`, `ExamRevisionQueue` deep-linking into Phase 3 & Phase 4 |
| `07_phase7_analytics_ai_tools_settings.md` | Study Analytics, AI Studio, 7 Lazy Tools Lab & Settings Studio | Phases 1–6 data & stores | SQL `Analytics` (lazy Recharts), `gemini-chat` Edge Function + `AIStudio`, 7 `React.lazy()` `ToolsLab` modules, full `Settings` Studio |
| `08_phase8_pwa_optimization_launch.md` | PWA, Bundle Chunking, Keep-Alive Cron & End-to-End QA | All Phases 0–7 | `vite-plugin-pwa`, Vite manual vendor chunks, Vercel Hobby `api/keepalive.ts` daily cron, final full-app QA & `README.md` |
