# PHASE 5 — 100% Global Music Studio & Draggable Floating Widgets (Ported from `essential.zip`)

## Startup Protocol
Read `AGENT_RULES.md`, `PROGRESS.md`, and Sections 9, 10.1, and 10.2 of `_docs/LOCUS_Project_Bible_v2.pdf`.
Inspect these behavioral reference files inside `_docs/essential/`:
- `src/components/widgets/FloatingPomodoro.tsx`
- `src/components/widgets/FloatingMusicPlayer.tsx`
- `src/context/MusicContext.tsx`
- `src/pages/Music.tsx`
- `src/components/notes/AudioPlayer.tsx`
- `src/router.tsx` (lines 1–35)

## Interconnections
- **100% Global Across All Workspaces:** `useMusicStore` and `FloatingMusicPlayer` NEVER filter by `activeWorkspaceId` and NEVER stop or reset when switching workspaces or routes.
- **Connects to Phase 3:** When a Pomodoro focus sprint completes in `usePomodoroStore`, if `autoPauseVideo === true`, call `usePlayerStore.getState().pauseForPomodoro()`.
- **Connects to Phase 2 & Phase 6/7:** Pomodoro completion plays `playThemeSfx('milestone')`, triggers a milestone event for Phase 6's ceremonial halo, and inserts a row into `focus_sessions` tagged with `activeWorkspaceId` and active `batchId` (feeding Phase 6 Heatmap and Phase 7 Analytics).

## Detailed Implementation Requirements

### 1. Offline Procedural Ambient Audio Engine (`src/lib/ambientAudio.ts`)
Build a zero-dependency Web Audio API engine (100% offline, ₹0, zero audio downloads):
- Synthesize 5 independently mixable ambient channels with smooth gain ramping (`linearRampToValueAtTime`):
  1. **Monsoon Rain** (bandpass-filtered white noise + soft droplet modulation)
  2. **Deep Brown Noise** (integrated Brownian noise filter for deep focus)
  3. **Warm Pink Noise** (Voss-McCartney / Kellet filter)
  4. **Torch Embers** (warm low-pass rumble + gentle randomized crackle impulses — pairs amazingly with *Baahubali* & *Ramayana*)
  5. **Night Breeze** (slow LFO-swept lowpass wind)
- Expose `setChannelVolume(channel, 0..1)`, `setMasterVolume`, `pauseAll`, `resumeAll`.

### 2. Global Music Store & Studio (`src/stores/useMusicStore.ts` & `src/pages/Music.tsx`)
- **3 Reliable ₹0 Sources (Drop Spotify 30s Previews):**
  1. **Offline Ambient Mixer** (runs independently or layered softly under tracks).
  2. **Personal Supabase MP3/WAV Tracks:** Upload to `locus-media/{uid}/audio/{id}.mp3`, save metadata to `music_tracks`, cache blobs in `dexie.ts` for offline playback.
  3. **Clean YouTube Lo-Fi Audio Queue:** Port `parseImportLink()` from `_docs/essential/src/context/MusicContext.tsx` and drive clean YouTube IFrame audio playback (zero fragile Invidious proxies required).
- **Atomic Progress Updates:** Keep `currentTime` / `duration` updates isolated via atomic Zustand selectors so 1-second scrub ticks never re-render the Music Studio grid or Dock.
- **Audio Note Player (`src/components/notes/AudioPlayer.tsx`):** Clean glass HTML5 player ported from `_docs/essential/` for audio notes in Phase 4's Library.

### 3. Draggable Floating Widgets (`src/components/widgets/`)
Port the exact tactile drag, pin, minimize, and expand flow from `_docs/essential/` onto atomic Zustand stores:
- **`FloatingMusicPlayer.tsx`:**
  - Uses `motion/react` `useMotionValue(x, y)`, viewport `dragConstraints`, `dragElastic={0.08}`, `dragMomentum={false}`, `onDragEnd` saving coordinates to `localStorage` (`locus_music_pos`, `locus_music_pinned`).
  - Supports Pin/Unpin lock (disables drag when pinned), Compact Pill <-> Expanded Mini Studio morph, Play/Pause, Next/Prev, Ambient quick toggle, and Volume slider.
- **`FloatingPomodoro.tsx` + `src/stores/usePomodoroStore.ts`:**
  - Same `motion/react` drag/pin/minimize/expand mechanics (`locus_pomo_pos`, `locus_pomo_pinned`), surviving page refreshes via `targetEndTimestamp`.
  - Modes: `Pomodoro (25m)`, `Deep Work (50m)`, `Sprint (15m)`, `Short Break (5m)` + `autoPauseVideo` toggle.
  - On reaching `00:00`: calls `usePlayerStore.getState().pauseForPomodoro()`, triggers `playThemeSfx('milestone')`, and writes a completed session to Supabase `focus_sessions`.
- **Global Mounting (`src/router.tsx`):**
  - Mount `<FloatingMusicPlayer />` on all routes except `/auth`.
  - Mount `<FloatingPomodoro />` on all routes except `/auth` and `/study`.

## Verification Gate
- Run `npx tsc --noEmit` and `npm run build` -> 0 errors.
- Test dragging, pinning, minimizing, and expanding both widgets; start Rain + Brown Noise + a track, then switch between `Upgrade Yourself`, `CIE`, and `Exam` workspaces and across routes -> verify zero audio cuts and smooth 60fps dragging at `1440px` and `390px`.
- Mark Phase 5 `[x]` in `PROGRESS.md` and stop.
