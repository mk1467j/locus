# PHASE 1 — 100% Pure Supabase Backend, SQL Schema, Storage RLS & Auth Portal

## Startup Protocol
Read `AGENT_RULES.md`, `PROGRESS.md`, and Sections 2 & 3 of `_docs/LOCUS_Project_Bible_v2.pdf`.

## Interconnections
- **Consumes:** Phase 0 repository scaffold and dependencies.
- **Exposes to Phases 2–8:**
  - Complete 13-table PostgreSQL schema (`supabase/migrations/001_initial_schema.sql`) with GIN-indexed `workspace_ids uuid[]` and InitPlan RLS.
  - Private Storage bucket `locus-media` with native per-user folder RLS.
  - `src/lib/supabase.ts`, `src/lib/dexie.ts`, `src/lib/queryClient.ts`, `src/lib/utils.ts`.
  - `src/stores/useAuthStore.ts` (Google OAuth + Email + Native Anonymous Guest Sign-In + 1-click `linkIdentity` upgrade).
  - `src/types/database.ts` (strict TypeScript interfaces for every table).

## Detailed Implementation Requirements

### 1. Complete SQL Migration (`supabase/migrations/001_initial_schema.sql`)
Write a clean, idempotent PostgreSQL migration creating ALL 13 tables with UUID primary keys, `created_at`/`updated_at` timestamps, and strict foreign keys:
1. `profiles`: `id uuid PK REFERENCES auth.users(id) ON DELETE CASCADE`, `display_name text`, `active_workspace_id uuid`, `theme_id text DEFAULT 'default'`, `surface_mode text DEFAULT 'frosted-glass'`, `primary_hex text DEFAULT '#8B5CF6'`, `secondary_hex text DEFAULT '#00F0FF'`, `ritual_copy_on boolean DEFAULT true`, `sfx_on boolean DEFAULT true`, `motion_mode text DEFAULT 'full'`, `wallpaper_path text`, `daily_goal_mins int DEFAULT 180`.
2. `workspaces`: `id`, `user_id`, `name`, `slug`, `icon`, `badge_color`, `theme_override text`, `sort_order int`, `is_archived boolean DEFAULT false`.
3. `folders`: `id`, `user_id`, `parent_id uuid REFERENCES folders(id) ON DELETE CASCADE`, `workspace_ids uuid[] NOT NULL DEFAULT '{}'`, `name`, `color`.
4. `materials`: `id`, `user_id`, `folder_id uuid REFERENCES folders(id) ON DELETE SET NULL`, `workspace_ids uuid[] NOT NULL DEFAULT '{}'`, `title`, `file_type text CHECK (file_type IN ('note','pdf','video','audio','image','link'))`, `content_md text`, `storage_path text`, `file_size_bytes bigint`, `is_offline_pinned boolean DEFAULT false`, `linked_batch_id uuid`.
5. `pdf_annotations`: `id`, `user_id`, `material_id uuid REFERENCES materials(id) ON DELETE CASCADE`, `page_number int`, `strokes_json jsonb`, `highlights_json jsonb`, `comments_json jsonb` + unique constraint on `(user_id, material_id, page_number)`.
6. `batches`: `id`, `user_id`, `workspace_ids uuid[] NOT NULL DEFAULT '{}'`, `playlist_id text`, `title`, `channel_title text`, `thumbnail_url text`, `linked_folder_id uuid REFERENCES folders(id) ON DELETE SET NULL`.
7. `batch_videos`: `id`, `user_id`, `batch_id uuid REFERENCES batches(id) ON DELETE CASCADE`, `source_type text CHECK (source_type IN ('youtube','supabase'))`, `youtube_id text`, `storage_path text`, `title`, `position int`, `duration_sec int DEFAULT 0`, `last_watched_sec int DEFAULT 0`, `is_completed boolean DEFAULT false`, `linked_material_id uuid REFERENCES materials(id) ON DELETE SET NULL`.
8. `video_notes`: `id`, `user_id`, `batch_id uuid REFERENCES batches(id) ON DELETE CASCADE`, `video_id uuid REFERENCES batch_videos(id) ON DELETE CASCADE`, `workspace_ids uuid[] NOT NULL DEFAULT '{}'`, `timestamp_sec int NOT NULL`, `content_md text NOT NULL`, `is_revision_flagged boolean DEFAULT false`.
9. `revision_queue`: `id`, `user_id`, `workspace_ids uuid[] NOT NULL DEFAULT '{}'`, `source_type text CHECK (source_type IN ('video_note','pdf_highlight','manual'))`, `title`, `excerpt text`, `deep_link text NOT NULL`, `priority text DEFAULT 'high'`, `next_review_at timestamptz`, `mastery_level int DEFAULT 0`, `is_resolved boolean DEFAULT false`.
10. `tasks`: `id`, `user_id`, `workspace_id uuid REFERENCES workspaces(id) ON DELETE CASCADE`, `title`, `notes text`, `priority text DEFAULT 'medium'`, `batch_id uuid REFERENCES batches(id) ON DELETE SET NULL`, `due_at timestamptz`, `is_done boolean DEFAULT false`.
11. `sticky_notes`: `id`, `user_id`, `workspace_id uuid REFERENCES workspaces(id) ON DELETE CASCADE`, `title`, `body text`, `color_token text`, `col_status text DEFAULT 'todo'`, `sort_order int DEFAULT 0`.
12. `focus_sessions`: `id`, `user_id`, `workspace_id uuid REFERENCES workspaces(id) ON DELETE SET NULL`, `mode text`, `duration_mins int`, `batch_id uuid REFERENCES batches(id) ON DELETE SET NULL`, `completed_at timestamptz DEFAULT now()`.
13. `music_tracks`: `id`, `user_id`, `title`, `artist text`, `source_type text CHECK (source_type IN ('supabase','youtube'))`, `storage_path text`, `youtube_id text`, `cover_url text`, `playlist_tag text` *(Globally shared — no workspace_id!)*.
14. `tools_data`: `id`, `user_id`, `workspace_id uuid REFERENCES workspaces(id) ON DELETE CASCADE`, `tool_type text CHECK (tool_type IN ('whiteboard','flashcards','quizzes','mindmaps','planner','goals','formulas'))`, `payload_json jsonb NOT NULL DEFAULT '{}'::jsonb`.

**Performance Indexes & RLS:**
- Add `CREATE INDEX` on `user_id` for every table.
- Add `CREATE INDEX ... USING GIN (workspace_ids)` on `folders`, `materials`, `batches`, `video_notes`, and `revision_queue`.
- Enable RLS on every table using InitPlan caching: `USING (user_id = (SELECT auth.uid())) WITH CHECK (user_id = (SELECT auth.uid()))` (and `id = (SELECT auth.uid())` on `profiles`).
- Create private bucket `locus-media` (50 MB max file size) with native folder RLS: `bucket_id = 'locus-media' AND (storage.foldername(name))[1] = (SELECT auth.uid()::text)`.
- Create `handle_new_user()` trigger on `auth.users` that inserts the user's `profiles` row AND seeds 3 starter workspaces: `Upgrade Yourself` (`upgrade-yourself`), `CIE` (`cie`), and `Exam` (`exam`), setting `active_workspace_id` to `Exam`.

### 2. Core Client Libraries (`src/lib/`)
- `supabase.ts`: Export typed `supabase` client + `isSupabaseConfigured` boolean helper so local UI preview degrades gracefully into local-demo mode when `.env` is empty.
- `dexie.ts`: Dexie database `locus_offline_db` with `blobs` (`&storagePath, mimeType, sizeBytes, cachedAt`) + helper functions `cacheBlob`, `getCachedBlob`, `evictOldestBlobs`, `getCacheStats`.
- `queryClient.ts`: Configured `QueryClient` (`staleTime: 60_000`, `gcTime: 1000 * 60 * 30`, `retry: 1`).
- `utils.ts`: `cn(...inputs)`, `safeJsonParse<T>(raw, fallback)`, `formatDuration(sec)`, `formatRelativeTime(iso)`.

### 3. Auth Store & Cinematic Auth Portal
- `src/stores/useAuthStore.ts`: Handles `initialize()` (`onAuthStateChange`), `signInWithGoogle()`, `signInWithEmail()`, `signUpWithEmail()`, `signInAsGuest()` (`signInAnonymously()`), `upgradeGuestWithGoogle()` (`linkIdentity({ provider: 'google' })`), `signOut()`, and tracks `isAnonymous` so a subtle "Link Google Account to Sync Forever" pill appears for guests.
- `src/pages/Auth.tsx`: High-craft OLED split/centered Auth portal (desktop & mobile `100dvh`) with Google OAuth button, Email/Password toggle, and 1-click "Enter Instant Guest Mode" button.
- `src/router.tsx`: TanStack Router setup with `/auth` and lazy-loaded route placeholders for all 14 app routes.

## Verification Gate
- Run `npx tsc --noEmit` and `npm run build` -> 0 errors.
- Validate `001_initial_schema.sql` syntax carefully (no missing commas, valid Postgres syntax).
- Launch dev server and visually inspect `/auth` in browser at `1440px` desktop and `390px` mobile.
- Mark Phase 1 `[x]` in `PROGRESS.md` and stop.
