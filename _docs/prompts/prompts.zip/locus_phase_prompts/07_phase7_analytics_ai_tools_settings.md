# PHASE 7 — Study Analytics, AI Studio, 7 Lazy Tools Lab Modules & Full Settings Studio

## Startup Protocol
Read `AGENT_RULES.md`, `PROGRESS.md`, and Sections 6, 9, and 11 of `_docs/LOCUS_Project_Bible_v2.pdf`.

## Interconnections
- **Consumes:**
  - All structured data from Phases 1–6 (`focus_sessions`, `batch_videos`, `tasks`, `revision_queue`, `video_notes`, `materials`, `workspaces`, `profiles`).
  - Phase 2 `useThemeStore`, `useWorkspaceStore`, `switchThemeWithIris`, `playThemeSfx`, and Phase 1 `dexie.ts` cache stats.

## Detailed Implementation Requirements

### 1. Study Analytics (`src/pages/Analytics.tsx` — Lazy-Loaded Recharts)
- Lazy-load chart components so `recharts` never bloats initial bundle size.
- KPI row: **Total Focus Hours**, **Global Study Streak**, **Lectures Mastered (90%+)**, and **Exam Queue Clearance %**.
- **Per-Workspace Breakdown:** Progress bars & bar chart comparing hours spent across `Upgrade Yourself`, `CIE`, `Exam`, and custom workspaces.
- **90-Day Unified Activity Heatmap** + **Weekly Daily-Goal Bar Chart** themed dynamically to `--accent-from` and `--accent-to`.

### 2. AI Studio (`supabase/functions/gemini-chat/index.ts` & `src/pages/AIStudio.tsx`)
- **Supabase Edge Function (`gemini-chat`):** Calls Google's free **Gemini 2.5 Flash** (`gemini-2.5-flash`) using `Deno.env.get('GEMINI_API_KEY')`, accepting `{ messages, workspaceContext }` with clean error handling and zero client-side key exposure.
- **Live Gemini Study Workspace:** Clean chat interface with **1-Click Workspace Context Chips**:
  - *"+ Attach Active Lecture Notes"* (pulls recent `video_notes` from active workspace)
  - *"+ Attach Active PDF Highlights"* (pulls recent `pdf_annotations` excerpts)
  - *"+ Quiz Me on Exam Revision Queue"* (injects unresolved `revision_queue` items)
- **External Model Launchers (₹0, Zero Broken Iframes):** Sleek glass cards for **ChatGPT**, **Claude**, and **NotebookLM** that assemble a clean structured study prompt with your active workspace context, copy it to clipboard with toast confirmation, and open the target platform in a new tab.

### 3. Tools Lab (`src/pages/Tools.tsx` + 7 `React.lazy()` Micro-Modules in `src/pages/tools/`)
Each tool MUST be its own lazy-loaded file (`React.lazy()`) reading/writing cleanly to Supabase `tools_data` scoped by `activeWorkspaceId`:
1. `Whiteboard.tsx`: Smooth HTML5 canvas freehand pen, eraser, color swatches, clear, and Export PNG.
2. `Flashcards.tsx`: Create decks, 3D CSS flip animation, and Easy/Good/Hard confidence tracking.
3. `QuizBuilder.tsx`: Create custom MCQ quizzes, play timed quiz mode, and review final score.
4. `MindMaps.tsx`: Interactive node creation, parent-child SVG connectors, drag positioning, and zoom.
5. `StudyPlanner.tsx`: Weekly 7-day study block scheduler with color-coded subject blocks.
6. `Goals.tsx`: Semester CGPA / coding / exam goal tracker with live progress sliders.
7. `FormulaSheets.tsx`: Subject-grouped monospace & Unicode mathematical formula quick-reference cards.

### 4. Settings & Full Theme/Offline Studio (`src/pages/Settings.tsx`)
- **2-Axis Appearance Studio:**
  - Interactive selector for all **6 Surface Modes** (`100% Liquid Glass`, `Frosted Glass`, `Light`, `Dark`, `Extra Dark OLED`, `Minimalist`).
  - Interactive cards for all **7 Theme Packs** (`Default`, `Baahubali`, `RRR`, `KGF`, `Ramayana`, `Cricket`, `Custom`) triggering `switchThemeWithIris(themeId, e)` on click!
  - **Default Theme Color Pickers:** Live Primary & Secondary hex pickers + curated preset swatches, persisted to `profiles.primary_hex` / `secondary_hex`.
  - **Custom Wallpaper Uploader:** Uploads wallpaper to `locus-media/{uid}/wallpapers/...` with live Blur and Dim sliders.
- **Immersion & Player Controls:** Toggles for **3D WebP Icons**, **Theme Ritual Copy**, **Offline Web Audio Micro-SFX**, **Motion Intensity** (`Full Cinema` / `Subtle` / `Minimal`), `CLEAN_EMBED_MODE`, default playback speed, and Pomodoro `autoPauseVideo`.
- **Workspace Manager:** Create, rename, reorder, set per-workspace `theme_override`, or archive workspaces.
- **Storage & Dexie Offline Manager:** Displays Supabase Storage usage (`X MB / 1,024 MB`) and Dexie cached blobs (`getCacheStats()`) with 1-click **"Clear Offline Cache"**.

## Verification Gate
- Run `npx tsc --noEmit` and `npm run build` -> 0 errors.
- Inspect Vite build output and confirm `recharts` and all 7 `pages/tools/*.tsx` files compile into separate lazy chunks.
- Test every Settings control live (including Default custom Primary/Secondary colors, 100% Liquid Glass, and Workspace Manager) at `1440px` and `390px`.
- Mark Phase 7 `[x]` in `PROGRESS.md` and stop.
