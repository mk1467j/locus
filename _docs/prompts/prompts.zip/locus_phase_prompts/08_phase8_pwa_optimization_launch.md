# PHASE 8 — Production Hardening, PWA, Bundle Splitting, Keep-Alive Cron & Final QA

## Startup Protocol
Read `AGENT_RULES.md`, `PROGRESS.md`, and Sections 2, 11, and 12 of `_docs/LOCUS_Project_Bible_v2.pdf`.

## Interconnections
- Finalizes, optimizes, and verifies ALL Phases 0–7 into a single production-ready, zero-cost, installable PWA deployed on Vercel Hobby + Supabase Free.

## Detailed Implementation Requirements

### 1. Installable PWA & Offline Caching (`vite.config.ts` & `public/manifest.webmanifest`)
- Configure `vite-plugin-pwa` (`registerType: 'autoUpdate'`) with LOCUS name, `#050508` theme/background color, `display: 'standalone'`, minimalist geometric SVG + maskable PNG icons.
- Configure Workbox runtime caching so `public/icons/themes/**/*.webp` (3D icon packs) and Google Fonts cache cleanly offline with `CacheFirst`.

### 2. Vite Manual Vendor Chunking (`vite.config.ts`)
Configure `build.rollupOptions.output.manualChunks` to split heavy libraries into cleanly cached vendor bundles:
- `vendor-react`: `react`, `react-dom`, `@tanstack/react-router`, `@tanstack/react-query`, `zustand`
- `vendor-supabase`: `@supabase/supabase-js`
- `vendor-motion`: `motion`
- `vendor-pdf`: `pdfjs-dist`
- `vendor-charts`: `recharts`
- `vendor-dexie`: `dexie`

### 3. Zero-Cost Supabase Keep-Alive Cron (`api/keepalive.ts` & `vercel.json`)
- Create `api/keepalive.ts` (Vercel Serverless Function) issuing a lightweight `HEAD`/`SELECT` health ping to Supabase REST API using `SUPABASE_URL` & `SUPABASE_ANON_KEY` env vars, returning `200 OK { ok: true, timestamp }`.
- Create `vercel.json` with SPA rewrite (`/(.*)` -> `/index.html`) AND Vercel Hobby's free daily cron:
  `"crons": [{ "path": "/api/keepalive", "schedule": "0 8 * * *" }]` so the Supabase Free project never pauses after 7 days of inactivity.

### 4. End-to-End Zero-Dead-Controls & Visual Polish Audit
Walk through EVERY route (`/`, `/auth`, `/batches`, `/batches/$id`, `/library`, `/revision`, `/focus`, `/study`, `/tasks`, `/sticky-walls`, `/music`, `/analytics`, `/ai-studio`, `/tools`, `/settings`) and fix any remaining defects:
- Zero TypeScript warnings/errors, zero console errors, zero dead buttons or unlinked placeholders.
- Confirm **Workspace Switching** works globally AND inside Batchify; confirm **Music & Pomodoro** persist uninterrupted across every switch.
- Confirm **Active-First Notes/PDFs** + **"Show Other Workspaces"** + 1-tap `workspace_ids[]` pinning work cleanly.
- Confirm **100% Liquid Glass**, **Light Mode**, **Extra Dark OLED**, **Default** custom primary/secondary colors, and **Baahubali / RRR / KGF / Ramayana / Cricket** themes all have WCAG-legible contrast.
- Confirm mobile (`390px`, `100dvh`) has **0px horizontal overflow** and zero bottom-bar clipping.

### 5. Deployment Guide (`README.md`)
Write a clear, 10-minute launch `README.md` covering:
1. Running `supabase/migrations/001_initial_schema.sql` in Supabase SQL Editor.
2. Enabling Google OAuth + Anonymous Sign-Ins in Supabase Auth.
3. Deploying `youtube-playlist` and `gemini-chat` Edge Functions and setting `YOUTUBE_API_KEY` + `GEMINI_API_KEY` secrets.
4. Deploying to Vercel Hobby with `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`.

## Final Verification Gate
- Run `npx tsc --noEmit` and `npm run build` -> 0 errors, verified vendor chunks.
- Inspect final desktop (`1440px`) and mobile (`390px`) screenshots across key routes.
- Mark Phase 8 `[x]` in `PROGRESS.md` and report final build summary.
