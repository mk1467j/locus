# PHASE 6 — Dashboard Command Center, Focus & Cinematic Mode, Tasks, Sticky Walls & Exam Revision Queue

## Startup Protocol
Read `AGENT_RULES.md`, `PROGRESS.md`, and Sections 4, 5, and 6.5 of `_docs/LOCUS_Project_Bible_v2.pdf`.

## Interconnections
- **Consumes:**
  - Phase 2 `useWorkspaceStore`, `useThemeStore`, `getRitualCopy`, `playThemeSfx`, `<LocusIcon />`.
  - Phase 3 `batches` & `batch_videos` (Continue Learning + deep-link target `/batches/$batchId?v=$vid&t=$sec`).
  - Phase 4 `materials` (offline-pinned PDF + deep-link target `/library?materialId=$id&page=$page`).
  - Phase 5 `usePomodoroStore`, `useMusicStore`, `focus_sessions`.
- **Exposes to Phase 7:** Populated `tasks`, `focus_sessions`, and `revision_queue` data for Study Analytics and AI Studio context chips.

## Detailed Implementation Requirements

### 1. Dashboard Command Center (`src/pages/Dashboard.tsx`)
Design an asymmetric 12-column editorial command center (single-column stacked on `< 768px`):
- **Editorial Hero:** `Playfair Display` ritual greeting (`getRitualCopy(themeId, 'greeting')`), active workspace badge, and primary Focus CTA button.
- **Continue Learning (8 cols):**
  - Most recently watched Batchify lecture card (thumbnail, `Resume MM:SS` pill, progress bar, note count) linking straight to `/batches/$batchId?v=$videoId&t=$lastWatchedSec`.
  - Most recent offline-pinned PDF card (`p. X / Y`, highlight count) linking straight to `/library?materialId=$id`.
- **Today's Mission (4 cols):** Active workspace's top 5 uncompleted tasks with instant checkbox completion (`playThemeSfx('complete')`) + optional **"Show Urgent Across All Workspaces"** toggle.
- **90-Day Unified Study Activity Heatmap (7 cols):** Theme-adaptive intensity cells (`background: var(--accent-from)` with opacity steps) aggregating `focus_sessions` across ALL workspaces + global streak badge.
- **Global Audio & Quick Launch (5 cols):** Live readout of playing ambient/music track + 1-tap launch tiles to `Exam Revision Queue`, `AI Studio`, `Tools Lab`, `Sticky Walls`, and `Analytics`.

### 2. Focus Mode (`src/pages/Focus.tsx`) & Cinematic Study Mode (`src/pages/StudyMode.tsx`)
- **Focus Mode:** Large `JetBrains Mono` chronometer bound via atomic selector to `usePomodoroStore`, mode switcher (`25m / 50m / 15m / 5m`), active workspace target task spotlight, inline Global Ambient Mixer sliders, and **"Enter Cinematic Study Mode"** button.
- **Cinematic Study Mode (`/study`):** Distraction-free `100dvh` full-screen canvas (desktop + landscape mobile) showcasing a `Playfair Display` philosophical/study quote, floating minimal chronometer, live ambient canvas atmosphere, and quiet Play/Pause + Exit controls.
- **Ceremonial Milestone Payoff (`MilestoneHalo.tsx`):** Completing a focus sprint triggers a GPU-only radial halo expansion (`scale 0.8 -> 1.6`, `opacity 0.6 -> 0`, `650ms`) + rolling streak counter + `playThemeSfx('milestone')`.

### 3. Tasks (`src/pages/Tasks.tsx`) & Sticky Walls (`src/pages/StickyWalls.tsx`)
- **Tasks (Mission Control):** Filterable by `All / Today / High Priority / Completed`, scoped to `activeWorkspaceId`, with optional `batch_id` linking, due dates, and optimistic TanStack Query mutations to `tasks`.
- **Sticky Walls:** 4-column glass sticky-note board (`To Do`, `In Progress`, `Review`, `Mastered`), scoped to `activeWorkspaceId`, with quick color-token picker, inline edit, and smooth column move transitions synced to `sticky_notes`.

### 4. Exam Revision Queue (`src/pages/ExamRevisionQueue.tsx`)
- Queries `revision_queue` filtered by `activeWorkspaceId` (with **"Show Other Workspaces"** toggle).
- Displays priority badge (`HIGH / MEDIUM`), source badge (`VIDEO PIN @ 18:42` or `PDF HIGHLIGHT · p. 14`), excerpt, and two crisp buttons:
  - **"Jump to Source ->"**: Navigates directly to `item.deep_link` (auto-seeking Phase 3's player to the exact second or opening Phase 4's PDF Studio at the exact page).
  - **"Mark Mastered"**: Updates `is_resolved = true`, plays `playThemeSfx('complete')`, and triggers the Ceremonial Milestone Payoff when the queue is cleared!

## Verification Gate
- Run `npx tsc --noEmit` and `npm run build` -> 0 errors.
- Test end-to-end deep-link loop: Flag a video second in Phase 3 (`R`) -> open `/revision` -> click "Jump to Source" -> confirm player opens at that exact timestamp. Repeat for a Phase 4 PDF highlight.
- Inspect all 5 pages at `1440px` and `390px` across `Default`, `Baahubali`, and `Cricket` themes.
- Mark Phase 6 `[x]` in `PROGRESS.md` and stop.
