# PHASE 0 — Master Context Lock, Agent Rules & Clean Repository Scaffold

## Role & Mission
You are the **Lead Principal Full-Stack Engineer and Visual Craft Director** building **LOCUS** from scratch — a unified, mobile-first Learning Operating System merging **StudyVibe** and **Batchify**.

## Mandatory Reading Before Any Action
1. Read `_docs/LOCUS_Project_Bible_v2.pdf` completely. It is the **SINGLE SOURCE OF TRUTH** and overrides all other files.
2. Read `_docs/essential/MANIFEST.md` and inspect the directory tree of `_docs/essential/`. Treat `_docs/essential/` strictly as a **behavioral reference** for draggable widget physics, music controls, and Batches extraction — **NEVER** copy or import legacy Firebase, Express, or `localStorage`-only code from it.

## Non-Negotiable Architecture & Craft Laws
1. **100% Pure Supabase + Dexie.js (Strictly ₹0/month):**
   - ZERO Firebase packages (`firebase`, `firestore`, `firebase-admin`).
   - ZERO Express server (`express`, `server.ts`).
   - ZERO fragile YouTube scrapers (`ytdl-core`, `ytpl`, `youtube-dl-exec`).
   - Every service runs inside verified ₹0 free tiers (Supabase Free, YouTube Data API v3, Google Gemini 2.5 Flash Free Tier, Vercel Hobby).
2. **S. S. Rajamouli Visual Craft Standard (Anti-Generic-AI):**
   - Reject flat, repetitive AI-generated purple-card layouts.
   - Craft optical rim-lit glass, chiaroscuro directional lighting, 2% film grain, colourful 3D transparent WebP icons on hero surfaces, tactile spring choreography, and zero dead controls.
3. **Layout & Navigation Law:**
   - Desktop (`>= 1024px`): **Common Floating Desktop Dock** anchored at the bottom (NO wide left sidebar rail).
   - Mobile (`< 768px`): Fixed 5-tab thumb-zone bottom bar (`Home`, `Batches`, `Library`, `Focus`, `Settings`) using `100dvh` and `env(safe-area-inset-bottom)`.
4. **Performance & Complexity Law:**
   - Normalized `Record<id, T>` Zustand stores ($O(1)$ lookups), atomic selectors for live timer/audio ticks, route-level `React.lazy()`, virtualized lists (`@tanstack/react-virtual`), virtualized $O(1)$ PDF viewport canvases, and GPU-composited animations only (`transform`, `opacity`, `clip-path`).

## Phase 0 Deliverables (Do NOT Build Feature Pages Yet)
1. **Scaffold Vite 6 + React 19 + TypeScript + Tailwind CSS v4** in the repository root.
2. **Install Exact Clean Dependencies:**
   - Runtime: `react`, `react-dom`, `@tanstack/react-router`, `@tanstack/react-query`, `zustand`, `@supabase/supabase-js`, `dexie`, `motion`, `lucide-react`, `pdfjs-dist`, `@tanstack/react-virtual`, `recharts`, `clsx`, `tailwind-merge`.
   - Dev: `typescript`, `vite`, `@vitejs/plugin-react`, `@tailwindcss/vite`, `vite-plugin-pwa`, `@types/node`.
3. **Configure Project Tooling:**
   - Path alias `@/` -> `./src` in `tsconfig.json` and `vite.config.ts`.
   - Load `Playfair Display`, `Inter`, and `JetBrains Mono` cleanly in `index.html`, with a crisp minimalist geometric focal-point SVG favicon (`public/favicon.svg`) and title `LOCUS — Learning Operating System`.
4. **Create Empty Modular Directory Tree:**
   - `supabase/migrations/`, `supabase/functions/youtube-playlist/`, `supabase/functions/gemini-chat/`
   - `api/`
   - `public/icons/themes/{default,baahubali,rrr,kgf,ramayana,cricket}/`
   - `src/{theme,lib,stores,types,pages/tools}`
   - `src/components/{layout,ui,player,pdf,widgets}`
5. **Create Persistent Governance Files:**
   - `AGENT_RULES.md`: Concise, binding checklist of all Non-Negotiable Laws, file naming conventions, TypeScript strictness, and verification gates for every future chat session.
   - `PROGRESS.md`: Phase 0 through Phase 8 checklist with space for verified completion notes per phase.
   - `.env.example`: Contains ONLY `VITE_SUPABASE_URL=` and `VITE_SUPABASE_ANON_KEY=`, plus comments documenting Supabase Edge Function secrets (`YOUTUBE_API_KEY`, `GEMINI_API_KEY`).

## Verification Gate (Must Pass Before Stopping)
- Run `npx tsc --noEmit` and `npm run build` -> must exit with `0` errors.
- Confirm `package.json` has ZERO Firebase, Express, or YouTube scraper packages.
- Mark Phase 0 `[x]` in `PROGRESS.md` and stop. Do NOT start Phase 1 yet.
