# PHASE 2 — Visual Soul: Common Desktop Dock, Mobile Bar, Multi-Workspace OS, 2-Axis 42-Combination Theme Engine, 3D Icons & Screenplay Motion

## Startup Protocol
Read `AGENT_RULES.md`, `PROGRESS.md`, and Sections 4, 5, and 6 (including Axis 1, Axis 2, and Axis 3 Screenplay Motion) of `_docs/LOCUS_Project_Bible_v2.pdf`.

## Interconnections
- **Consumes:** Phase 1 `profiles` & `workspaces` tables, `useAuthStore`, `supabase.ts`, `router.tsx`.
- **Exposes to Phases 3–8:**
  - Persistent App Shell (`AppShell.tsx`, `TopHud.tsx`, `DesktopDock.tsx`, `MobileBottomNav.tsx`, `CommandPalette.tsx`, `AmbientCanvas.tsx`).
  - `useWorkspaceStore` (`activeWorkspaceId`, `workspaces`, `setActiveWorkspace`, `createWorkspace`, `updateWorkspace`, `direction` for parallax pan).
  - `useThemeStore` (`surfaceMode`, `themeId`, `primaryHex`, `secondaryHex`, `ritualCopyOn`, `sfxOn`, `motionMode`, `switchThemeWithIris`).
  - Reusable UI primitives (`GlassCard`, `FlowButton`, `TelemetryBadge`, `LocusIcon`, `BottomSheet`, `WorkspaceSwitcher`).
  - `playThemeSfx()` and `getRitualCopy()` utilities.

## Detailed Implementation Requirements

### 1. 2-Axis CSS Token System (`src/theme/themes.css` & `src/styles/index.css`)
Implement two orthogonal HTML attributes (`<html data-surface="..." data-theme="...">`) yielding **6 × 7 = 42 live O(1) combinations**:
- **Axis 1 (`data-surface`):**
  1. `liquid-glass` (**100% Liquid Glass**): `rgba(255, 255, 255, 0.06)`, `backdrop-filter: blur(36px) saturate(210%)`, crisp double specular rim (`inset 0 1px 1px rgba(255,255,255,0.32), inset 0 -1px 1px rgba(255,255,255,0.06)`), plus a lightweight GPU cursor-follow specular highlight CSS radial gradient (`--mx`, `--my`) on `.glass-card`.
  2. `frosted-glass`: `rgba(18, 27, 38, 0.55)`, `blur(22px) saturate(150%)`, `1px` specular top highlight.
  3. `light`: Crisp alabaster `#F8FAFC` canvas, `#FFFFFF` cards, WCAG AAA `#0F172A` text, soft elevation shadows.
  4. `dark`: Midnight slate `#0B0F1A` canvas, `#131A2A` cards.
  5. `extra-dark`: Pure pixel-off OLED `#000000` canvas, ultra-clean hairline borders, zero glow spill.
  6. `minimalist`: Flat matte surfaces, zero blur, zero particles (maximum speed/focus).
- **Axis 2 (`data-theme`):**
  1. `default`: Driven by live user-picked CSS variables `--user-primary` (default `#8B5CF6`) and `--user-secondary` (default `#00F0FF`) synced to `profiles.primary_hex` & `profiles.secondary_hex`.
  2. `baahubali`: Mahishmati royal gold `#E5A93C -> #B8731A`, ember `#F97316`, basalt obsidian tint.
  3. `rrr`: Fire crimson `#EF4444 -> #F59E0B` & Water storm-cyan `#0EA5E9` dual-corner chiaroscuro lighting.
  4. `kgf`: Kolar molten gold `#D4AF37 -> #8A6D1D`, ash amber `#FBBF24`, smoky charcoal noir.
  5. `ramayana`: Sacred saffron `#F59E0B -> #EA580C`, temple bronze `#D97706`, serene twilight indigo.
  6. `cricket`: Floodlit stadium emerald `#10B981 -> #059669`, leather seam crimson `#E11D48`.
  7. `custom`: Uploaded Supabase wallpaper layer with adjustable blur/dim overlay + adaptive accent.
- Add a 2% inline SVG film-grain overlay and a throttled `<AmbientCanvas />` (embers / rain / gold dust / diya bokeh / floodlight cones) that pauses on `document.hidden`, `minimalist` surface, or `motionMode === 'minimal'`.

### 2. Colourful 3D WebP Icon Registry (`src/theme/iconRegistry.ts` & `src/components/ui/LocusIcon.tsx`)
- For hero slots (`dashboard`, `batches`, `library`, `revision`, `focus`, `tasks`, `music`, `analytics`, `ai`, `tools`, `settings`, plus workspace icons): render `<img src="/icons/themes/${themeId}/${name}.webp" loading="lazy" decoding="async" />` with theme-matched `drop-shadow(0 8px 16px var(--icon-glow))`.
- Include an automatic, high-craft glossy 3D-styled radial-gradient fallback badge if a `.webp` file hasn't been dropped into `public/icons/themes/` yet (so there are NEVER broken image icons!).
- Keep crisp 14–16px `lucide-react` micro-icons for small inline buttons.

### 3. Ritual Copy, Web Audio Micro-SFX & Screenplay Motion (`src/theme/`)
- `ritualCopy.ts`: Maps each theme to personalized hero greetings, Focus CTAs (*"Command the Session"*, *"Ignite Sprint"*, *"Forge Mastery"*, *"Begin Tapasya"*, *"Start Innings"*, *"Enter Deep Focus"*), and milestone messages—falling back to clean standard copy when `ritualCopyOn === false`.
- `sfx.ts`: Pure Web Audio API offline synthesizer (`AudioContext` lazily unlocked on first user gesture) producing distinct subtle cues per theme (glass tap, royal gong, kinetic pulse, anvil resonance, temple bell, willow bat knock).
- `motion.ts`:
  - `switchThemeWithIris(nextTheme, clickEvent)`: Exact native **View Transitions API** circular iris wipe (`clip-path: circle(0px at x y) -> circle(maxR at x y)`, `520ms`, `cubic-bezier(0.22, 1, 0.36, 1)`), with clean instant fallback when unsupported or `motionMode === 'minimal'`.
  - Shared spring presets: `SPRING_DOCK` (`mass: 0.1, stiffness: 260, damping: 18`), `SPRING_PILL` (`stiffness: 380, damping: 30`), `SPRING_HERO` (`stiffness: 320, damping: 28`).

### 4. Multi-Workspace OS & Navigation Shell
- `useWorkspaceStore.ts`: Normalized `Record<id, Workspace>`, starter spaces (`Upgrade Yourself`, `CIE`, `Exam`), `activeWorkspaceId` (`uuid | 'all'`), `switchDirection` (`-1 | 1`), keyboard shortcuts `Alt+1..9`, and automatic application of `workspace.theme_override` if set.
- `WorkspaceSwitcher.tsx`: Reusable glass pill switcher with `motion/react` `layoutId="workspace-pill"` (used in `TopHud` AND reused inside Phase 3's Batchify header!).
- `DesktopDock.tsx`: Bottom-centered floating glass dock with macOS-style `useMotionValue(mouseX)` + `useTransform` + `useSpring` 3D icon proximity wave magnification (`scale 1.0 -> 1.22`, `y 0 -> -8px`), active route glow indicator (`layoutId="dock-active"`), and crisp tooltips.
- `MobileBottomNav.tsx`: Fixed 5-tab thumb-zone bar (`Home`, `Batches`, `Library`, `Focus`, `Settings`) with `100dvh` and `env(safe-area-inset-bottom)`.
- `AppShell.tsx`: Wraps route outlet in directional parallax `AnimatePresence mode="popLayout"` when switching workspaces while keeping `DesktopDock`, `TopHud`, and Phase 5's floating widgets anchored rock-steady on the foreground plane.
- `CommandPalette.tsx`: `Ctrl/Cmd + K` quick switcher & search modal with "Active Workspace / All Workspaces" toggle.

## Verification Gate
- Run `npx tsc --noEmit` and `npm run build` -> 0 errors.
- Test in browser at `1440px` and `390px`: switch across `100% Liquid Glass`, `Light`, `Extra Dark OLED`, `Baahubali`, `RRR`, `Cricket`, and `Default` with custom Primary/Secondary colors; verify iris wipe, parallax workspace pan, and Desktop Dock proximity wave run at 60fps.
- Mark Phase 2 `[x]` in `PROGRESS.md` and stop.
